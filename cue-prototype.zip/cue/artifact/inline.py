"""Inlines artifact/app.js + artifact/app.css into one self-contained artifact/index.html."""
import base64
import pathlib

d = pathlib.Path(__file__).parent
css = (d / "app.css").read_text()
js = (d / "app.js").read_text().replace("</script", "<\\/script")
icon = base64.b64encode((d.parent / "app" / "icon.png").read_bytes()).decode()
html = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>cue. prototype</title>
<link rel="icon" href="data:image/png;base64,{icon}">
<style>{css}</style></head>
<body><div id="root"></div><script>{js}</script></body></html>"""
(d / "index.html").write_text(html)
print(f"artifact/index.html written ({len(html):,} bytes)")
