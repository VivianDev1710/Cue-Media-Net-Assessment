/**
 * Parses the daily Cue Markdown library into a structured ContentLibrary.
 * Pure function (no fs) so it can be unit-tested or reused by a future backend.
 *
 * Extraction rules (explicit, heading-driven — not positional):
 *  - Full stories:  "## CUE-xxx — Headline" blocks inside "## Full Content Library".
 *  - Within a story, every "### Heading" either switches mode
 *    (Metadata / 20-second cue / 2-minute brief — Standard / 2-minute brief — Too technical /
 *     5-minute deep dive / Why it matters to you / Prototype interaction mapping)
 *    or is a section heading inside the current mode.
 *  - Persona implications: "#### Role label" inside "Why it matters to you".
 *  - Backups: "### CUE-Bxx — Headline" blocks inside "## Backup Stories".
 *  - Ranks: any markdown table row whose second cell is a story ID.
 */
import type {
  BackupStory,
  BriefSection,
  ContentLibrary,
  PersonaImplication,
  PersonaKey,
  Story,
} from "../types/story";

const clean = (s: string) => s.replace(/\*\*/g, "").replace(/`/g, "").trim();

function splitByHeading(text: string, level: number): { heading: string; body: string }[] {
  const marker = "#".repeat(level) + " ";
  const lines = text.split("\n");
  const out: { heading: string; body: string[] }[] = [];
  let cur: { heading: string; body: string[] } | null = null;
  for (const line of lines) {
    if (line.startsWith(marker)) {
      cur = { heading: line.slice(marker.length).trim(), body: [] };
      out.push(cur);
    } else if (cur) {
      cur.body.push(line);
    }
  }
  return out.map((s) => ({ heading: s.heading, body: s.body.join("\n").trim() }));
}

function parseBullets(body: string): Record<string, string> {
  const map: Record<string, string> = {};
  for (const line of body.split("\n")) {
    const m = line.match(/^\s*-\s+\*\*(.+?):\*\*\s*(.*)$/);
    if (m) map[m[1].trim().toLowerCase()] = m[2].trim();
  }
  return map;
}

/** Paragraphs separated by blank lines. Bullet blocks ("- item" lines) keep one item per line. HTML comments are dropped. */
function paragraphs(body: string): string {
  return body
    .replace(/<!--[\s\S]*?-->/g, "")
    .split(/\n\s*\n/)
    .map((p) => {
      const lines = p.split("\n").map((l) => l.trim()).filter(Boolean);
      if (lines.length && lines.every((l) => /^[-*]\s+/.test(l))) return lines.map((l) => "- " + l.replace(/^[-*]\s+/, "")).join("\n");
      return lines.join(" ");
    })
    .filter((p) => p && p !== "---")
    .join("\n\n");
}

function personaKeyFor(label: string): PersonaKey | null {
  const l = label.toUpperCase();
  if (l.startsWith("CHRO")) return "CHRO";
  if (l.startsWith("CEO")) return "CEO";
  if (l.startsWith("CFO")) return "CFO";
  if (l.startsWith("COO")) return "COO";
  if (l.startsWith("CTO")) return "CTO";
  if (l.startsWith("CMO")) return "CMO";
  return null;
}

function parseRanks(md: string): Record<string, number> {
  const ranks: Record<string, number> = {};
  for (const line of md.split("\n")) {
    if (!line.startsWith("|")) continue;
    const cells = line.split("|").map((c) => c.trim());
    // cells[0] is "" (leading pipe)
    const rank = parseInt(cells[1], 10);
    const id = cells[2];
    if (!Number.isNaN(rank) && /^CUE-/.test(id ?? "")) ranks[id] = rank;
  }
  return ranks;
}

function tagsFor(category: string): string[] {
  return category
    .split(/,|&/)
    .map((t) => t.trim())
    .filter(Boolean);
}

type Mode = "none" | "meta" | "cue" | "standard" | "simple" | "deep" | "persona" | "done";

function parseStory(id: string, headline: string, body: string, rank: number, warnings: string[]): Story {
  const sections = splitByHeading(body, 3);
  let mode: Mode = "none";
  let meta: Record<string, string> = {};
  let cue20 = "";
  let cardSummary = "";
  const standard: BriefSection[] = [];
  const simple: BriefSection[] = [];
  const deep: BriefSection[] = [];
  const personas: PersonaImplication[] = [];

  for (const { heading, body: secBody } of sections) {
    const h = heading.toLowerCase();
    if (h === "metadata") { mode = "meta"; meta = parseBullets(secBody); continue; }
    if (h.startsWith("20-second cue")) {
      mode = "cue";
      // first bold line is the headline repeat; the rest is the cue text
      cue20 = paragraphs(secBody.replace(/^\*\*.*\*\*\s*$/m, ""));
      continue;
    }
    if (h.startsWith("cue card summary")) { cardSummary = paragraphs(secBody); continue; }
    if (h.startsWith("2-minute brief") && h.includes("standard")) { mode = "standard"; continue; }
    if (h.startsWith("2-minute brief") && h.includes("technical")) { mode = "simple"; continue; }
    if (/^\d+-minute deep dive|^deep dive/.test(h)) { mode = "deep"; continue; }
    if (h.startsWith("why it matters to you")) {
      mode = "persona";
      for (const p of splitByHeading(secBody, 4)) {
        const key = personaKeyFor(p.heading);
        if (key) personas.push({ key, label: p.heading, body: paragraphs(p.body) });
      }
      continue;
    }
    if (h.startsWith("prototype interaction mapping")) { mode = "done"; continue; }

    const section: BriefSection = { heading, body: paragraphs(secBody) };
    if (/<!--\s*Cue analysis/i.test(secBody)) section.analysis = true;
    if (mode === "standard") standard.push(section);
    else if (mode === "simple") simple.push(section);
    else if (mode === "deep") deep.push(section);
  }

  const story: Story = {
    id,
    rank,
    headline: clean(headline),
    category: meta["category"] ?? "News",
    source: meta["source"] ?? "",
    sourceUrl: meta["direct url"] ?? "",
    publishedAt: meta["publication date/time"] ?? "",
    geography: meta["geographic relevance"],
    importance: parseInt(meta["importance"] ?? "3", 10) || 3,
    rankingRationale: meta["ranking rationale"],
    cue20,
    cardSummary: cardSummary || undefined,
    briefStandard: standard,
    briefSimplified: simple,
    deepDive: deep,
    personaImplications: personas,
    image: meta["image"] || undefined,
    tags: tagsFor(meta["category"] ?? ""),
  };

  const corr = meta["corroborating source"];
  if (corr) {
    const m = corr.match(/^(.*?)\s+—\s+(https?:\/\/\S+)/);
    story.corroboratingSource = m ? m[1] : corr;
    story.corroboratingUrl = m ? m[2] : undefined;
  }

  const req: [string, unknown][] = [
    ["category", meta["category"]],
    ["source", story.source],
    ["direct url", story.sourceUrl],
    ["20-second cue", story.cue20],
    ["Cue card summary", story.cardSummary],
    ["2-minute brief — Standard", standard.length],
    ["2-minute brief — Too technical", simple.length],
    ["5-minute deep dive", deep.length],
    ["persona implications", personas.length],
  ];
  for (const [name, v] of req) if (!v) warnings.push(`${id}: missing ${name}`);
  if (personas.length && personas.length < 6) warnings.push(`${id}: only ${personas.length}/6 personas`);
  if (!story.image) warnings.push(`${id}: no image (a generated category visual will be used)`);
  return story;
}

export function parseLibrary(md: string): ContentLibrary {
  const warnings: string[] = [];
  const normalised = md.replace(/\r\n/g, "\n");
  const ranks = parseRanks(normalised);
  const top = splitByHeading(normalised, 2);

  // Header bullets live before the first "## "
  const headerMeta = parseBullets(normalised.split("\n## ")[0]);

  const stories: Story[] = [];
  const backups: BackupStory[] = [];
  let interactionCopy: Record<string, string> = {};
  let inBackups = false;

  for (const sec of top) {
    const m = sec.heading.match(/^(CUE-\d+)\s+[—-]\s+(.+)$/);
    if (m) {
      stories.push(parseStory(m[1], m[2], sec.body, ranks[m[1]] ?? 999, warnings));
      continue;
    }
    if (/^backup stories/i.test(sec.heading)) {
      inBackups = true;
      for (const b of splitByHeading(sec.body, 3)) {
        const bm = b.heading.match(/^(CUE-B\d+)\s+[—-]\s+(.+)$/);
        if (!bm) continue;
        const f = parseBullets(b.body);
        backups.push({
          id: bm[1],
          rank: ranks[bm[1]],
          headline: clean(bm[2]),
          category: f["category"] ?? "",
          summary: f["summary"] ?? "",
          source: f["source"] ?? "",
          sourceUrl: f["url"] ?? "",
        });
      }
      continue;
    }
    if (/^prototype interaction copy/i.test(sec.heading)) {
      interactionCopy = Object.fromEntries(
        Object.entries(parseBullets(sec.body)).map(([k, v]) => [k, v.replace(/^[“"]|[”"]$/g, "")]),
      );
    }
  }
  void inBackups;

  stories.sort((a, b) => a.rank - b.rank);
  if (!stories.length) warnings.push("No full stories found — check '## CUE-xxx — Headline' headings.");

  return {
    meta: {
      date: headerMeta["date"] ?? "",
      generatedAt: headerMeta["generated timestamp"] ?? "",
      editorialStatus: headerMeta["editorial status"],
      builtAt: new Date().toISOString(),
    },
    stories,
    backups,
    interactionCopy,
    warnings,
  };
}
