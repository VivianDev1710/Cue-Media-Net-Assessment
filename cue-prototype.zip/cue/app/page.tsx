import CueRoot from "@/components/CueRoot";

export default function Page() {
  return <CueRoot />;
}
