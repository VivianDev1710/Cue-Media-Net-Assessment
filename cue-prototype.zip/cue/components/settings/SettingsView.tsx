"use client";

import { RotateCcw, Volume2 } from "lucide-react";
import { useState } from "react";
import ProfileFields from "@/components/setup/ProfileFields";
import { ChromeIcon, TeamsIcon } from "@/components/shared/BrandIcons";
import { Button, SectionLabel, Toggle } from "@/components/shared/ui";
import { playChime } from "@/lib/sound";
import { useApp } from "@/lib/state";

export default function SettingsView() {
  const { state, setProfile, setPermissions, setSound, reset, toast } = useApp();
  const [confirming, setConfirming] = useState(false);

  return (
    <section className="mx-auto max-w-[880px] px-5 pt-10 pb-24 sm:px-10">
      <h1 className="font-serif text-[32px] font-semibold text-navy">Settings</h1>
      <p className="mt-1 text-[14px] text-muted">Changes apply immediately — your role decides the “Why it matters to you” view.</p>

      <div className="mt-8 rounded-2xl border border-line bg-white p-6 sm:p-8">
        <SectionLabel>Profile</SectionLabel>
        <div className="mt-4">
          <ProfileFields profile={state.profile} onChange={setProfile} />
        </div>
      </div>

      <div className="mt-6 rounded-2xl border border-line bg-white p-6 sm:p-8">
        <SectionLabel>Connections & sound</SectionLabel>
        <ul className="mt-4 divide-y divide-line">
          <li className="flex items-center gap-4 py-3">
            <TeamsIcon size={26} />
            <div className="flex-1">
              <p className="text-[14px] font-semibold text-navy">Microsoft Teams</p>
              <p className="text-[12.5px] text-muted">Connected · required for in-meeting cues</p>
            </div>
            <span className="text-[12px] font-semibold text-[#2f7a4f]">On</span>
          </li>
          <li className="flex items-center gap-4 py-3">
            <ChromeIcon size={26} />
            <div className="flex-1">
              <label htmlFor="set-chrome" className="text-[14px] font-semibold text-navy">
                Chrome (Work)
              </label>
              <p className="text-[12.5px] text-muted">Optional · show Cue on supported work sites</p>
            </div>
            <Toggle id="set-chrome" checked={state.permissions.chrome} onChange={(v) => setPermissions({ chrome: v })} label="Chrome (Work)" />
          </li>
          <li className="flex items-center gap-4 py-3">
            <span className="flex h-[26px] w-[26px] items-center justify-center text-navy">
              <Volume2 size={20} aria-hidden />
            </span>
            <div className="flex-1">
              <label htmlFor="set-sound" className="text-[14px] font-semibold text-navy">
                Meeting notification sound
              </label>
              <p className="text-[12.5px] text-muted">A subtle chime when a meeting invitation appears</p>
            </div>
            <Toggle
              id="set-sound"
              checked={state.soundOn}
              onChange={(v) => {
                setSound(v);
                if (v) void playChime();
              }}
              label="Meeting notification sound"
            />
          </li>
        </ul>
      </div>

      <div className="mt-6 rounded-2xl border border-line bg-white p-6 sm:p-8">
        <SectionLabel>Prototype</SectionLabel>
        <p className="mt-3 text-[14px] text-muted">Clear your profile, saved and read stories, and start the demo from the beginning.</p>
        {!confirming ? (
          <Button variant="secondary" className="mt-4" onClick={() => setConfirming(true)}>
            <RotateCcw size={15} aria-hidden /> Reset prototype
          </Button>
        ) : (
          <div className="mt-4 flex flex-wrap items-center gap-3 rounded-lg bg-[#fdecea] px-4 py-3" role="alertdialog" aria-label="Confirm reset">
            <p className="flex-1 text-[13.5px] font-medium text-[#7a1f16]">Reset everything? This can’t be undone.</p>
            <Button variant="secondary" size="sm" onClick={() => setConfirming(false)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              size="sm"
              onClick={() => {
                reset();
                toast("Prototype reset");
              }}
            >
              Yes, reset
            </Button>
          </div>
        )}
      </div>
    </section>
  );
}
