"use client";

import { ArrowLeft, MicOff, Users } from "lucide-react";
import { TeamsIcon } from "@/components/shared/BrandIcons";
import { MEETING } from "@/lib/constants";
import { formatElapsed, useApp, useNow } from "@/lib/state";

/** Slim strip shown above the reader while a meeting is running. Never interrupts reading. */
export default function MeetingBanner() {
  const { state, closeReader } = useApp();
  const now = useNow();
  const { joinedAt, participantJoinedAt } = state.meeting;
  const joined = Boolean(participantJoinedAt);

  return (
    <div className="flex shrink-0 flex-wrap items-center gap-x-4 gap-y-1 bg-[#292929] px-4 py-2 text-[13px] text-white/85 sm:px-6" role="region" aria-label="Meeting status">
      <span className="flex items-center gap-2 font-semibold text-white">
        <TeamsIcon size={18} /> {MEETING.title}
      </span>
      <span className="tabular-nums text-white/60">{formatElapsed(now - (joinedAt ?? now))}</span>
      <span className="flex items-center gap-1.5 text-white/70">
        <Users size={14} aria-hidden /> {joined ? `${MEETING.participantName} joined` : "Waiting for others to join…"}
      </span>
      {joined && (
        <span key="status" className="flex animate-fade-in items-center gap-1.5 text-white/60" role="status">
          <MicOff size={13} aria-hidden /> No one has started speaking yet.
        </span>
      )}
      <button
        type="button"
        onClick={closeReader}
        className="ml-auto inline-flex h-8 items-center gap-1.5 rounded-md bg-teams px-3 text-[13px] font-semibold text-white hover:bg-[#5254a0]"
      >
        <ArrowLeft size={14} aria-hidden /> Return to meeting
      </button>
    </div>
  );
}
