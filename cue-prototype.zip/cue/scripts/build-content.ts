/**
 * npm run build-content
 * Reads data/cue_news_today.md → validates → writes data/stories.json (bundled into the app).
 * Runs automatically before `npm run dev` and `npm run build`.
 */
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { join } from "node:path";
import { parseLibrary } from "../lib/content-parser";

const root = process.cwd();
const src = join(root, "data", "cue_news_today.md");
const out = join(root, "data", "stories.json");

if (!existsSync(src)) {
  if (existsSync(out)) {
    console.warn(`[build-content] ${src} not found — keeping existing stories.json`);
    process.exit(0);
  }
  console.error(`[build-content] Missing content file: ${src}`);
  process.exit(1);
}

const lib = parseLibrary(readFileSync(src, "utf8"));
writeFileSync(out, JSON.stringify(lib, null, 2));

console.log(`[build-content] ${lib.stories.length} full stories, ${lib.backups.length} backups → data/stories.json`);
for (const s of lib.stories) {
  console.log(
    `  ${s.id}  std:${s.briefStandard.length} simple:${s.briefSimplified.length} deep:${s.deepDive.length} personas:${s.personaImplications.length}  ${s.headline}`,
  );
}
const serious = lib.warnings.filter((w) => !w.includes("no image"));
if (lib.warnings.length) {
  console.log(`[build-content] ${lib.warnings.length} warning(s):`);
  for (const w of lib.warnings) console.log("  - " + w);
}
if (!lib.stories.length) process.exit(1);
void serious;
