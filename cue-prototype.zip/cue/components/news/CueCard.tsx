"use client";

import { ArrowRight, Bookmark, BookmarkCheck, Check, ChevronUp, Clock, Ellipsis, EyeOff, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import StoryVisual from "@/components/shared/StoryVisual";
import { Logo } from "@/components/shared/ui";
import { copy, stories } from "@/lib/content";
import { useApp } from "@/lib/state";

/** Compact in-meeting overlay showing the 20-second cue for the head of the queue. */
export default function CueCard({ attention = false }: { attention?: boolean }) {
  const { state, queue, openStory, markReadAndNext, notNow, hideToday, toggleSave, setCardCollapsed, toast } = useApp();
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const story = queue[0];

  useEffect(() => {
    if (!menuOpen) return;
    const close = (e: MouseEvent) => {
      if (!menuRef.current?.contains(e.target as Node)) setMenuOpen(false);
    };
    const esc = (e: KeyboardEvent) => e.key === "Escape" && setMenuOpen(false);
    document.addEventListener("mousedown", close);
    document.addEventListener("keydown", esc);
    return () => {
      document.removeEventListener("mousedown", close);
      document.removeEventListener("keydown", esc);
    };
  }, [menuOpen]);

  if (state.cardCollapsed && story) {
    return (
      <button
        type="button"
        onClick={() => setCardCollapsed(false)}
        className="mx-auto flex animate-rise items-center gap-3 rounded-full bg-white px-4 py-2 text-[13px] text-navy shadow-lg hover:bg-ivory"
      >
        <Logo className="text-[17px]" />
        <span className="text-muted">
          {queue.length} {queue.length === 1 ? "story" : "stories"} waiting
        </span>
        <span className="flex items-center gap-1 font-semibold">
          Show <ChevronUp size={14} aria-hidden />
        </span>
      </button>
    );
  }

  if (!story) {
    return (
      <div className="mx-auto w-full max-w-[640px] animate-rise rounded-xl bg-white px-5 py-4 text-navy shadow-[0_18px_50px_-18px_rgba(0,0,0,0.6)]">
        <div className="flex items-center gap-2 text-[12px] text-muted">
          <Logo className="text-[17px]" /> <span>· In your loop</span>
        </div>
        <p className="mt-1.5 text-[15px] font-semibold">
          {copy("no more stories in queue", "You’re caught up. We’ll have more important stories when there’s something worth your attention.")}
        </p>
      </div>
    );
  }

  const saved = state.savedIds.includes(story.id);
  const position = stories.findIndex((s) => s.id === story.id) + 1;

  return (
    <article
      key={story.id}
      aria-label={`Cue story: ${story.headline}`}
      className={`relative mx-auto w-full max-w-[740px] rounded-xl bg-white text-navy shadow-[0_18px_50px_-18px_rgba(0,0,0,0.6)] ${
        attention ? "animate-cue-in" : "animate-rise"
      }`}
    >
      <div className="flex items-center gap-2 px-4 pt-3.5 text-[12px] text-muted sm:px-5">
        <Logo className="text-[18px]" />
        <span aria-hidden>·</span>
        <span>In your loop</span>
        <span aria-hidden>·</span>
        <span className="min-w-0 flex-1 truncate font-medium text-teams">{story.category}</span>
        <button
          type="button"
          onClick={() => setCardCollapsed(true)}
          aria-label="Minimise Cue"
          title="Minimise"
          className="-mr-1.5 rounded-md p-1.5 text-muted hover:bg-navy/5 hover:text-navy"
        >
          <X size={17} />
        </button>
      </div>
      <div className="flex gap-4 px-4 pt-1 pb-4 sm:px-5">
        <div className="min-w-0 flex-1">
          <h2 className="text-[17px] leading-snug font-semibold">{story.headline}</h2>
          <p className="mt-1.5 text-[13.5px] leading-relaxed text-[#3d4a5f]">{story.cardSummary ?? story.cue20}</p>
        </div>
        <div className="hidden w-[124px] shrink-0 flex-col gap-2 sm:flex">
          <StoryVisual story={story} className="h-[78px] w-full rounded-lg" iconSize={28} />
          <p className="text-right text-[11px] text-muted">
            Story {position} of {stories.length} · 20 sec
          </p>
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-2 border-t border-line px-4 py-3 sm:px-5">
        <button
          type="button"
          onClick={() => openStory(story.id, "brief")}
          className="inline-flex h-9 items-center gap-2 rounded-lg bg-navy px-4 text-[13.5px] font-semibold text-white hover:bg-navy-2"
        >
          Know more <ArrowRight size={15} aria-hidden />
        </button>
        <button
          type="button"
          onClick={() => {
            markReadAndNext(story.id, "card");
            toast("Marked as read");
          }}
          className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-line px-3 text-[13.5px] font-semibold hover:bg-ivory"
        >
          <Check size={15} aria-hidden /> Mark as read &amp; next
        </button>
        <button
          type="button"
          onClick={() => {
            notNow(story.id);
            toast("Okay — we’ll bring it back later.");
          }}
          className="inline-flex h-9 items-center gap-1.5 rounded-lg px-3 text-[13.5px] font-medium text-muted hover:bg-navy/5 hover:text-navy"
        >
          <Clock size={15} aria-hidden /> Not now
        </button>
        <div className="ml-auto flex items-center gap-1">
          <button
            type="button"
            onClick={() => {
              toggleSave(story.id);
              toast(saved ? "Removed from Saved" : "Saved for later");
            }}
            aria-pressed={saved}
            aria-label={saved ? "Remove from saved" : "Save story"}
            title={saved ? "Saved" : "Save"}
            className="rounded-lg p-2 text-muted hover:bg-navy/5 hover:text-navy"
          >
            {saved ? <BookmarkCheck size={18} className="text-orange" /> : <Bookmark size={18} />}
          </button>
          <div className="relative" ref={menuRef}>
            <button
              type="button"
              onClick={() => setMenuOpen((v) => !v)}
              aria-haspopup="menu"
              aria-expanded={menuOpen}
              aria-label="More story options"
              className="rounded-lg p-2 text-muted hover:bg-navy/5 hover:text-navy"
            >
              <Ellipsis size={18} />
            </button>
            {menuOpen && (
              <div role="menu" className="absolute right-0 bottom-11 z-10 w-56 animate-fade-in rounded-lg border border-line bg-white p-1 shadow-xl">
                <button
                  role="menuitem"
                  type="button"
                  onClick={() => {
                    hideToday(story.id);
                    setMenuOpen(false);
                    toast("We won’t show this story again today.");
                  }}
                  className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-[13px] hover:bg-ivory"
                >
                  <EyeOff size={15} aria-hidden /> Don’t show this today
                </button>
                <button
                  role="menuitem"
                  type="button"
                  onClick={() => {
                    setCardCollapsed(true);
                    setMenuOpen(false);
                  }}
                  className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-[13px] hover:bg-ivory"
                >
                  <ChevronUp size={15} className="rotate-180" aria-hidden /> Minimise Cue
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </article>
  );
}
