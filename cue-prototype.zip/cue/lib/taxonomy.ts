/**
 * Setup taxonomy: functions, seniority, industries, topic and interest catalogues,
 * and the rules that suggest topics from a user's function + industry.
 * Static data only — a real product would serve this from a backend.
 */
import type { PersonaKey } from "@/types/story";

export interface Option {
  id: string;
  label: string;
}

export interface FunctionOption extends Option {
  persona: PersonaKey;
  exact: boolean; // false → no dedicated persona in the content library; closest one is used and labelled
}

export const FUNCTIONS: FunctionOption[] = [
  { id: "strategy", label: "Strategy & General Management", persona: "CEO", exact: true },
  { id: "finance", label: "Finance & Investment", persona: "CFO", exact: true },
  { id: "technology", label: "Technology & Engineering", persona: "CTO", exact: true },
  { id: "product", label: "Product & Design", persona: "CTO", exact: false },
  { id: "marketing", label: "Marketing & Communications", persona: "CMO", exact: true },
  { id: "sales", label: "Sales & Business Development", persona: "CMO", exact: true },
  { id: "operations", label: "Supply Chain & Operations", persona: "COO", exact: true },
  { id: "procurement", label: "Procurement", persona: "COO", exact: true },
  { id: "hr", label: "HR & Talent", persona: "CHRO", exact: true },
  { id: "legal", label: "Legal & Compliance", persona: "CEO", exact: false },
  { id: "consulting", label: "Consulting", persona: "CEO", exact: false },
  { id: "other", label: "Other", persona: "CEO", exact: false },
];

export const SENIORITY: Option[] = [
  "Manager",
  "Senior Manager",
  "Director",
  "Senior Director",
  "VP",
  "SVP / President",
  "C-suite",
  "Founder / Owner",
  "Other",
].map((label) => ({ id: label, label }));

export const INDUSTRIES: Option[] = [
  "Technology & Software",
  "IT Services & Outsourcing",
  "Internet & Consumer Tech",
  "Semiconductors & Electronics",
  "Telecommunications",
  "Media & Entertainment",
  "Gaming",
  "FMCG / Consumer Goods",
  "D2C Brands",
  "Retail & E-commerce",
  "Food & Beverage",
  "Fashion & Apparel",
  "Textiles",
  "Luxury",
  "Automotive & Mobility",
  "Electric Vehicles",
  "Manufacturing",
  "Industrial Goods & Machinery",
  "Steel",
  "Metals & Mining",
  "Chemicals",
  "Pharmaceuticals",
  "Healthcare Providers",
  "Medical Devices",
  "Biotech & Life Sciences",
  "Banking",
  "Insurance",
  "Asset Management",
  "Private Equity & Venture Capital",
  "Fintech",
  "NBFC & Lending",
  "Real Estate",
  "Construction & Infrastructure",
  "Oil & Gas",
  "Renewable Energy",
  "Power & Utilities",
  "Logistics & Supply Chain",
  "Transportation & Aviation",
  "Shipping & Ports",
  "Agriculture & Agritech",
  "Education & Edtech",
  "Hospitality & Travel",
  "Consulting & Professional Services",
  "Legal Services",
  "Government & Public Sector",
  "Non-profit & Development",
  "Defence & Aerospace",
  "Other",
].map((label) => ({ id: label, label }));

/** Broad work themes (formerly "business priorities"). They sit in the same 6-item selection as specific topics. */
export const THEMES = [
  "Growth & competition",
  "Technology & AI",
  "Customers & markets",
  "Strategy & transformation",
  "Regulation & policy",
  "Talent & leadership",
  "Supply chain & operations",
  "Finance & investment",
];

export interface CatalogGroup {
  group: string;
  items: string[];
}

export const TOPIC_CATALOG: CatalogGroup[] = [
  { group: "Broad themes", items: THEMES },
  {
    group: "Technology & AI",
    items: [
      "Generative AI", "AI regulation", "AI infrastructure & data centres", "Semiconductors", "Cloud computing",
      "Cybersecurity", "Data privacy", "Enterprise software & SaaS", "Automation & robotics", "Quantum computing",
      "Digital public infrastructure", "Telecom & 5G", "Big Tech", "Startups & venture capital", "Developer tools",
      "Edtech", "Healthtech", "Fintech & payments",
    ],
  },
  {
    group: "Markets & finance",
    items: [
      "Stock markets", "Indian equities", "Bond markets & yields", "Currencies & the rupee", "Interest rates & central banks",
      "Inflation", "Private equity", "IPOs & listings", "Banking", "Insurance", "Crypto & digital assets",
      "Corporate earnings", "Commodities", "Gold & precious metals", "Credit & lending", "ESG investing",
    ],
  },
  {
    group: "Economy",
    items: [
      "Indian economy", "US economy", "China economy", "Global growth", "PMI & business surveys", "Jobs & labour market",
      "Consumer spending", "Government budgets & fiscal policy", "GDP data", "Real estate & housing",
    ],
  },
  {
    group: "Trade & policy",
    items: [
      "Trade deals & tariffs", "India–EU trade", "India–US trade", "Export controls", "Sanctions", "Industrial policy & PLI",
      "Competition & antitrust", "Taxation & GST", "Labour law", "Regulation in India", "EU regulation", "Rice & agri exports",
    ],
  },
  {
    group: "Strategy & corporate",
    items: [
      "Mergers & acquisitions", "Competitor launches", "Business model innovation", "Corporate governance",
      "Leadership changes", "Restructuring & layoffs", "Partnerships & alliances", "Pricing strategy",
      "Family businesses & conglomerates", "Global capability centres",
    ],
  },
  {
    group: "Energy & climate",
    items: [
      "Oil & gas", "Renewable energy", "Solar power", "Energy storage & batteries", "Green hydrogen", "Climate policy & COP",
      "Carbon markets", "ESG reporting", "Electric vehicles", "Power grids & utilities", "Nuclear energy", "Water & resources",
    ],
  },
  {
    group: "Industries",
    items: [
      "Steel & metals", "Indian FMCG", "Retail & e-commerce", "Quick commerce", "Automotive", "Pharmaceuticals", "Healthcare",
      "Aviation", "Infrastructure & construction", "Railways", "Logistics & shipping", "Textiles & apparel", "Chemicals",
      "Agriculture & food", "Media & entertainment", "Gaming industry", "Real estate developers", "Hospitality & travel",
      "Defence & aerospace", "D2C brands",
    ],
  },
  {
    group: "Operations & supply chain",
    items: [
      "Supply chain resilience", "Procurement & sourcing", "Manufacturing", "China+1 & diversification",
      "Shipping & freight rates", "Inventory & demand planning", "Quality & compliance", "Commodity input costs",
    ],
  },
  {
    group: "People & work",
    items: [
      "Future of work", "Hiring & talent markets", "Skills & reskilling", "Hybrid & remote work", "Compensation & benefits",
      "Diversity & inclusion", "Employee wellbeing", "Leadership & culture",
    ],
  },
  {
    group: "Customers & marketing",
    items: [
      "Consumer trends", "Brand & advertising", "Digital marketing", "Customer experience", "Pricing & promotions",
      "Rural consumption", "Premiumisation", "B2B sales",
    ],
  },
  {
    group: "Legal & risk",
    items: [
      "Litigation & disputes", "Compliance & enforcement", "Data protection law", "Fraud & financial crime",
      "Geopolitical risk", "Climate & physical risk",
    ],
  },
];

export const INTEREST_CATALOG: CatalogGroup[] = [
  {
    group: "World & society",
    items: [
      "Geopolitics", "Elections", "Indian politics", "US politics", "Diplomacy", "Defence & security", "Human rights",
      "Migration", "Middle East", "China", "Europe", "Africa", "Urbanisation", "Education", "Public health",
    ],
  },
  {
    group: "Economy & ideas",
    items: ["Economy", "Behavioural economics", "Personal finance", "Investing", "Philanthropy", "Books & ideas", "Biographies", "History"],
  },
  {
    group: "Science & tech",
    items: [
      "Science", "Space exploration", "Physics", "Biology & genetics", "Medical breakthroughs", "Psychology", "Archaeology",
      "Gadgets", "Consumer tech", "AI in everyday life", "Robotics", "Climate science",
    ],
  },
  {
    group: "Sport",
    items: [
      "Football", "Cricket", "Tennis", "Formula 1", "Golf", "Badminton", "Basketball", "Athletics", "Olympics", "Chess",
      "Kabaddi", "Hockey", "Cycling", "Running & marathons", "Rugby", "Boxing", "Sailing", "Esports",
    ],
  },
  {
    group: "Culture & arts",
    items: [
      "Culture", "Films", "Bollywood", "Television & streaming", "Music", "Classical music", "Theatre", "Art & design",
      "Architecture", "Photography", "Literature", "Poetry", "Dance", "Fashion", "Museums & heritage", "Anime",
      "Podcasts", "Comedy", "K-culture",
    ],
  },
  {
    group: "Lifestyle",
    items: [
      "Food & dining", "Cooking", "Wine & spirits", "Coffee", "Travel", "Luxury", "Cars", "Motorbikes", "Watches",
      "Sneakers", "Home & interiors", "Gardening", "Pets", "Parenting",
    ],
  },
  {
    group: "Wellbeing",
    items: ["Wellness", "Fitness", "Yoga", "Mental fitness", "Nutrition", "Sleep", "Mindfulness", "Outdoors & hiking"],
  },
  { group: "Planet", items: ["Climate", "Wildlife & conservation", "Oceans", "Sustainable living", "Weather & natural disasters"] },
  { group: "Games & hobbies", items: ["Video games", "Board games", "Puzzles", "Collecting", "DIY & making", "Learning languages"] },
];

export const INTEREST_EXAMPLES = ["Geopolitics", "Football", "Economy", "Science", "Culture", "Climate", "Wellness"];

export const countItems = (c: CatalogGroup[]) => c.reduce((n, g) => n + g.items.length, 0);

const FUNCTION_TOPICS: Record<string, string[]> = {
  strategy: ["Competitor launches", "Mergers & acquisitions", "Generative AI", "Indian economy", "Trade deals & tariffs"],
  finance: ["Interest rates & central banks", "Currencies & the rupee", "Bond markets & yields", "Corporate earnings", "Mergers & acquisitions"],
  technology: ["Generative AI", "AI infrastructure & data centres", "Cybersecurity", "Semiconductors", "Cloud computing"],
  product: ["Generative AI", "Competitor launches", "Consumer trends", "Customer experience", "Enterprise software & SaaS"],
  marketing: ["Consumer trends", "Brand & advertising", "Digital marketing", "Competitor launches", "Generative AI"],
  sales: ["Competitor launches", "B2B sales", "Partnerships & alliances", "Pricing strategy", "Consumer trends"],
  operations: ["Supply chain resilience", "Shipping & freight rates", "Commodity input costs", "Trade deals & tariffs", "Manufacturing"],
  procurement: ["Procurement & sourcing", "Commodity input costs", "Trade deals & tariffs", "China+1 & diversification", "Supply chain resilience"],
  hr: ["Hiring & talent markets", "Skills & reskilling", "Future of work", "Labour law", "Generative AI"],
  legal: ["Regulation in India", "Data protection law", "Competition & antitrust", "Compliance & enforcement", "AI regulation"],
  consulting: ["Mergers & acquisitions", "Generative AI", "Business model innovation", "Indian economy", "Competitor launches"],
  other: ["Indian economy", "Generative AI", "Stock markets", "Competitor launches", "Trade deals & tariffs"],
};

const INDUSTRY_TOPICS: Record<string, string[]> = {
  "Technology & Software": ["Enterprise software & SaaS", "Generative AI"],
  "IT Services & Outsourcing": ["Global capability centres", "Generative AI"],
  "Internet & Consumer Tech": ["Quick commerce", "Startups & venture capital"],
  "Semiconductors & Electronics": ["Semiconductors", "Export controls"],
  Telecommunications: ["Telecom & 5G", "Regulation in India"],
  "Media & Entertainment": ["Media & entertainment", "Digital marketing"],
  Gaming: ["Gaming industry", "Startups & venture capital"],
  "FMCG / Consumer Goods": ["Indian FMCG", "Rural consumption"],
  "D2C Brands": ["D2C brands", "Digital marketing"],
  "Retail & E-commerce": ["Retail & e-commerce", "Quick commerce"],
  "Food & Beverage": ["Agriculture & food", "Commodity input costs"],
  "Fashion & Apparel": ["Textiles & apparel", "D2C brands"],
  Textiles: ["Textiles & apparel", "Trade deals & tariffs"],
  Luxury: ["Premiumisation", "Consumer trends"],
  "Automotive & Mobility": ["Automotive", "Electric vehicles"],
  "Electric Vehicles": ["Electric vehicles", "Energy storage & batteries"],
  Manufacturing: ["Manufacturing", "Industrial policy & PLI"],
  "Industrial Goods & Machinery": ["Manufacturing", "Infrastructure & construction"],
  Steel: ["Steel & metals", "Infrastructure & construction"],
  "Metals & Mining": ["Steel & metals", "Commodities"],
  Chemicals: ["Chemicals", "Commodity input costs"],
  Pharmaceuticals: ["Pharmaceuticals", "Quality & compliance"],
  "Healthcare Providers": ["Healthcare", "Healthtech"],
  "Medical Devices": ["Healthcare", "Quality & compliance"],
  "Biotech & Life Sciences": ["Pharmaceuticals", "Healthcare"],
  Banking: ["Banking", "Interest rates & central banks"],
  Insurance: ["Insurance", "Regulation in India"],
  "Asset Management": ["Stock markets", "Bond markets & yields"],
  "Private Equity & Venture Capital": ["Private equity", "IPOs & listings"],
  Fintech: ["Fintech & payments", "Regulation in India"],
  "NBFC & Lending": ["Credit & lending", "Interest rates & central banks"],
  "Real Estate": ["Real estate developers", "Real estate & housing"],
  "Construction & Infrastructure": ["Infrastructure & construction", "Railways"],
  "Oil & Gas": ["Oil & gas", "Climate policy & COP"],
  "Renewable Energy": ["Renewable energy", "Solar power"],
  "Power & Utilities": ["Power grids & utilities", "Renewable energy"],
  "Logistics & Supply Chain": ["Logistics & shipping", "Shipping & freight rates"],
  "Transportation & Aviation": ["Aviation", "Oil & gas"],
  "Shipping & Ports": ["Logistics & shipping", "Trade deals & tariffs"],
  "Agriculture & Agritech": ["Agriculture & food", "Rice & agri exports"],
  "Education & Edtech": ["Edtech", "Skills & reskilling"],
  "Hospitality & Travel": ["Hospitality & travel", "Consumer spending"],
  "Consulting & Professional Services": ["Business model innovation", "Global capability centres"],
  "Legal Services": ["Litigation & disputes", "Regulation in India"],
  "Government & Public Sector": ["Government budgets & fiscal policy", "Digital public infrastructure"],
  "Non-profit & Development": ["Climate policy & COP", "Healthcare"],
  "Defence & Aerospace": ["Defence & aerospace", "Export controls"],
};

/** One combined limit for themes + topics ("What matters to your work?"). */
export const MAX_TOPICS = 6;
export const MAX_INTERESTS = 5;
/** How many items are pre-selected for the user (leaves room for their own picks). */
export const PRESELECT_COUNT = 4;

const FUNCTION_THEME: Record<string, string> = {
  strategy: "Strategy & transformation",
  finance: "Finance & investment",
  technology: "Technology & AI",
  product: "Customers & markets",
  marketing: "Customers & markets",
  sales: "Growth & competition",
  operations: "Supply chain & operations",
  procurement: "Supply chain & operations",
  hr: "Talent & leadership",
  legal: "Regulation & policy",
  consulting: "Strategy & transformation",
  other: "Growth & competition",
};

/** Role-relevant specific topics: the industry's two most specific first, then the function's (deduplicated, up to 5). */
export function suggestTopics(functionId: string, industry: string): string[] {
  if (!functionId || !industry) return [];
  const merged = [...(INDUSTRY_TOPICS[industry] ?? []), ...(FUNCTION_TOPICS[functionId] ?? FUNCTION_TOPICS.other)];
  return Array.from(new Set(merged)).slice(0, 5);
}

/** The theme that best matches a function (one per function). */
export function suggestTheme(functionId: string): string | null {
  return functionId ? (FUNCTION_THEME[functionId] ?? null) : null;
}

/** Default selection: the function's theme + the top role topics, PRESELECT_COUNT items in total. */
export function defaultSelection(functionId: string, industry: string): string[] {
  const topics = suggestTopics(functionId, industry);
  if (!topics.length) return [];
  const theme = suggestTheme(functionId);
  return Array.from(new Set([...(theme ? [theme] : []), ...topics])).slice(0, PRESELECT_COUNT);
}

export function functionById(id: string): FunctionOption | undefined {
  return FUNCTIONS.find((f) => f.id === id);
}

/** Migration for prototype state saved before the function/seniority split. */
export const LEGACY_ROLE_TO_FUNCTION: Record<string, string> = {
  ceo: "strategy",
  cfo: "finance",
  coo: "operations",
  supply: "procurement",
  cto: "technology",
  cmo: "marketing",
  chro: "hr",
  other: "other",
};

/** Topics/interests a story relates to, for the "You follow …" label. */
export function storyTopics(text: string): string[] {
  const t = text.toLowerCase();
  const out: string[] = [];
  const add = (...x: string[]) => out.push(...x);
  if (/\bai\b|semiconductor|data-centre/.test(t)) add("Generative AI", "AI infrastructure & data centres", "Semiconductors", "Stock markets", "Technology & AI");
  if (/cop31|climate/.test(t)) add("Climate policy & COP", "Climate", "Geopolitics", "Geopolitical risk", "Regulation & policy");
  if (/steel/.test(t)) add("Steel & metals", "Mergers & acquisitions", "Infrastructure & construction", "Strategy & transformation", "Growth & competition");
  if (/private-sector|pmi|manufacturing/.test(t)) add("PMI & business surveys", "Indian economy", "Manufacturing", "Economy", "Customers & markets");
  if (/rupee|bond/.test(t)) add("Currencies & the rupee", "Bond markets & yields", "Interest rates & central banks", "Indian equities", "Investing", "Finance & investment");
  if (/trade|free-trade/.test(t)) add("Trade deals & tariffs", "India–EU trade", "Geopolitics", "Europe", "Regulation & policy");
  if (/oil and gas|import bill/.test(t)) add("Oil & gas", "Indian economy", "Currencies & the rupee", "Commodity input costs", "Supply chain & operations");
  if (/solar|battery/.test(t)) add("Solar power", "Energy storage & batteries", "Renewable energy", "Power grids & utilities");
  if (/markets|finance/.test(t)) add("Stock markets");
  return Array.from(new Set(out));
}
