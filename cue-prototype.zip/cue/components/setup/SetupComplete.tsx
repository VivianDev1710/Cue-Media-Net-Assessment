"use client";

import { Check, RotateCcw, Video } from "lucide-react";
import { useEffect } from "react";
import { Logo } from "@/components/shared/ui";
import { useApp } from "@/lib/state";

/** Confirmation screen. After exactly 2s the simulated Teams invitation appears (rendered by CueRoot). */
export default function SetupComplete() {
  const { state, showInvite, reset } = useApp();

  useEffect(() => {
    if (state.inviteVisible) return;
    const t = setTimeout(showInvite, 2000);
    return () => clearTimeout(t);
  }, [state.inviteVisible, showInvite]);

  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-ivory px-6 text-center">
      <Logo className="absolute top-6 left-8 text-[26px]" />
      <div className="animate-pop flex h-20 w-20 items-center justify-center rounded-full bg-navy text-white shadow-lg">
        <Check size={38} strokeWidth={2.4} aria-hidden />
      </div>
      <h1 className="mt-8 animate-rise font-serif text-[40px] leading-tight font-semibold text-navy">You’re all set.</h1>
      <p className="mt-2 animate-rise text-[16px] text-muted" style={{ animationDelay: "120ms" }}>
        Cue is ready to help you stay in the loop.
      </p>
      <p
        className="mt-8 inline-flex animate-rise items-center gap-2 rounded-full border border-[#d9d9f0] bg-white px-4 py-2 text-[15px] font-semibold text-navy shadow-sm"
        style={{ animationDelay: "240ms" }}
      >
        <Video size={17} className="text-teams" aria-hidden />
        Join the dummy Teams meeting to experience Cue.
      </p>
      <p className="mt-3 animate-fade-in text-[13px] text-muted" style={{ animationDelay: "400ms" }}>
        {state.inviteVisible ? "Your meeting invitation is in the bottom-right corner." : "Your meeting invitation is on its way…"}
      </p>
      <button
        type="button"
        onClick={reset}
        className="mt-10 inline-flex animate-fade-in items-center gap-2 rounded-lg px-4 py-2 text-[13.5px] font-semibold text-muted ring-1 ring-line hover:bg-white hover:text-navy"
        style={{ animationDelay: "500ms" }}
      >
        <RotateCcw size={15} aria-hidden /> Go to beginning of user journey
      </button>
    </main>
  );
}
