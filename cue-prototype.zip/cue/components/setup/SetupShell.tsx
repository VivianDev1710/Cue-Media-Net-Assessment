"use client";

import type { ReactNode } from "react";
import { Logo } from "@/components/shared/ui";

export default function SetupShell({ step, label, children }: { step: 1 | 2; label: string; children: ReactNode }) {
  return (
    <main className="min-h-screen bg-ivory px-4 py-8 sm:py-12">
      <div className="mx-auto w-full max-w-[980px] animate-rise overflow-hidden rounded-2xl border border-line bg-white shadow-[0_20px_60px_-30px_rgba(23,36,58,0.35)]">
        <header className="flex flex-wrap items-center gap-4 border-b border-line px-6 py-4 sm:px-10">
          <Logo className="text-[26px]" />
          <div className="flex flex-1 items-center gap-1.5" aria-hidden>
            <span className="h-1 w-24 rounded-full bg-navy" />
            <span className={`h-1 w-24 rounded-full ${step === 2 ? "bg-navy" : "bg-line"}`} />
          </div>
          <p className="text-[13px] text-muted">
            Step {step} of 2 · {label}
          </p>
        </header>
        <div className="px-6 py-8 sm:px-10 sm:py-10">{children}</div>
      </div>
    </main>
  );
}
