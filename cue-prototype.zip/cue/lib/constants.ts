// Setup options live in lib/taxonomy.ts. This file holds meeting simulation constants.

export const MEETING = {
  title: "Strategy Sync",
  time: "10:00 – 10:30",
  participantName: "Alex Morgan",
  /** Fixed, repeatable timings measured from the moment you join (every join/rejoin restarts them). */
  cardDelayMs: 2_000,
  participantDelayMs: 30_000,
};

/** Words per minute used for honest reading-time estimates of analytical text. */
export const READING_WPM = 200;
