/* Simplified, original glyphs suggesting Teams and Chrome for the simulated permissions/meeting UI. */

export function TeamsIcon({ size = 36 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" aria-hidden>
      <circle cx="29" cy="11" r="5" fill="#7b83eb" />
      <rect x="22" y="17" width="15" height="14" rx="5" fill="#7b83eb" />
      <circle cx="19" cy="9" r="6" fill="#5059c9" />
      <rect x="9" y="16" width="20" height="18" rx="6" fill="#5059c9" />
      <rect x="3" y="11" width="18" height="18" rx="3" fill="#4b53bc" />
      <path d="M8 15.5h8v2.2h-2.8V25h-2.4v-7.3H8z" fill="#fff" />
    </svg>
  );
}

export function ChromeIcon({ size = 36 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" aria-hidden>
      <circle cx="20" cy="20" r="17" fill="#e8eaed" />
      <path d="M20 3a17 17 0 0 1 14.7 8.5H20a8.5 8.5 0 0 0-7.4 4.3L7.3 6.6A17 17 0 0 1 20 3z" fill="#ea4335" />
      <path d="M34.7 11.5A17 17 0 0 1 21 37l7.4-12.8a8.5 8.5 0 0 0 0-8.4z" fill="#fbbc04" />
      <path d="M21 37A17 17 0 0 1 7.3 6.6l5.3 9.2a8.5 8.5 0 0 0 7.4 12.7h8.4z" fill="#34a853" />
      <circle cx="20" cy="20" r="6.5" fill="#fff" />
      <circle cx="20" cy="20" r="5" fill="#4285f4" />
    </svg>
  );
}
