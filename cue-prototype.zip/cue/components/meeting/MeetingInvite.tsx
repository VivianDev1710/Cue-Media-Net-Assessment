"use client";

import { CalendarClock, Video, Volume2, VolumeX, X } from "lucide-react";
import { useEffect, useRef } from "react";
import { TeamsIcon } from "@/components/shared/BrandIcons";
import { MEETING } from "@/lib/constants";
import { playChime } from "@/lib/sound";
import { useApp } from "@/lib/state";

/** Floating Teams-style meeting prompt, bottom-right. */
export default function MeetingInvite() {
  const { state, joinMeeting, dismissInvite, setSound } = useApp();
  const played = useRef(false);
  const joinRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!played.current && state.soundOn) {
      played.current = true;
      void playChime(); // silently does nothing if the browser blocks audio
    }
    joinRef.current?.focus({ preventScroll: true });
  }, [state.soundOn]);

  return (
    <div
      role="dialog"
      aria-labelledby="invite-title"
      className="fixed right-4 bottom-4 z-[60] w-[min(380px,calc(100vw-2rem))] animate-slide-in overflow-hidden rounded-xl bg-[#292929] text-white shadow-[0_24px_60px_-20px_rgba(0,0,0,0.6)] ring-1 ring-white/10 sm:right-6 sm:bottom-6"
    >
      <div className="flex items-center gap-2 border-b border-white/10 px-4 py-2.5 text-[12px] text-white/70">
        <TeamsIcon size={18} />
        <span className="flex-1">Microsoft Teams</span>
        <button
          type="button"
          onClick={() => {
            setSound(!state.soundOn);
            if (!state.soundOn) void playChime();
          }}
          className="rounded p-1 text-white/60 hover:bg-white/10 hover:text-white"
          aria-label={state.soundOn ? "Mute notification sound" : "Turn notification sound on"}
          title={state.soundOn ? "Sound on" : "Sound off"}
        >
          {state.soundOn ? <Volume2 size={15} /> : <VolumeX size={15} />}
        </button>
        <button
          type="button"
          onClick={dismissInvite}
          className="rounded p-1 text-white/60 hover:bg-white/10 hover:text-white"
          aria-label="Dismiss meeting invitation"
        >
          <X size={16} />
        </button>
      </div>
      <div className="flex gap-3 px-4 pt-4 pb-4">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-teams/25 text-[#c5c7f5]">
          <CalendarClock size={20} aria-hidden />
        </div>
        <div className="min-w-0">
          <p id="invite-title" className="text-[15px] font-semibold">
            {MEETING.title}
          </p>
          <p className="text-[13px] text-white/60">{MEETING.time} · Starting now</p>
          <p className="mt-1 text-[13px] text-white/80">Join your meeting</p>
        </div>
      </div>
      <div className="flex gap-2 px-4 pb-4">
        <button
          ref={joinRef}
          type="button"
          onClick={joinMeeting}
          className="inline-flex h-9 flex-1 items-center justify-center gap-2 rounded-md bg-teams text-[14px] font-semibold text-white hover:bg-[#5254a0]"
        >
          <Video size={16} aria-hidden /> Join
        </button>
        <button
          type="button"
          onClick={dismissInvite}
          className="inline-flex h-9 items-center justify-center rounded-md px-4 text-[14px] font-semibold text-white/85 ring-1 ring-white/20 hover:bg-white/10"
        >
          Dismiss
        </button>
      </div>
    </div>
  );
}
