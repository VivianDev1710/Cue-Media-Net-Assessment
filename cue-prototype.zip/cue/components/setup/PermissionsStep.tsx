"use client";

import { ArrowLeft, ArrowRight, Info, Lock } from "lucide-react";
import type { ReactNode } from "react";
import { ChromeIcon, TeamsIcon } from "@/components/shared/BrandIcons";
import SetupShell from "@/components/setup/SetupShell";
import { Button, Toggle } from "@/components/shared/ui";
import { primeAudio } from "@/lib/sound";
import { useApp } from "@/lib/state";

function PermissionRow({
  icon,
  name,
  badge,
  required,
  description,
  checked,
  onChange,
}: {
  icon: ReactNode;
  name: string;
  badge: string;
  required?: boolean;
  description: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  const id = `perm-${name.replace(/\W+/g, "-").toLowerCase()}`;
  return (
    <div className="flex items-start gap-4 rounded-xl border border-line bg-white p-5">
      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-ivory">{icon}</div>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <label htmlFor={id} className="text-[15px] font-semibold text-navy">
            {name}
          </label>
          <span
            className={`rounded px-1.5 py-0.5 text-[11px] font-semibold ${
              required ? "bg-orange-soft text-[#b5630f]" : "bg-ivory text-muted"
            }`}
          >
            {badge}
          </span>
        </div>
        <p className="mt-1 text-[13.5px] leading-relaxed text-muted">{description}</p>
      </div>
      <Toggle id={id} checked={checked} onChange={onChange} label={`${name} access`} />
    </div>
  );
}

export default function PermissionsStep() {
  const { state, setPermissions, goTo, finishSetup } = useApp();
  const { teams, chrome } = state.permissions;

  return (
    <SetupShell step={2} label="Permissions">
      <h1 className="font-serif text-[32px] leading-tight font-semibold text-navy">Connect Cue to your work tools</h1>
      <p className="mt-1.5 text-[15px] text-muted">Allow Cue to show relevant news at the right moments in your workday.</p>

      <div className="mt-8 max-w-[680px] space-y-3">
        <PermissionRow
          icon={<TeamsIcon size={30} />}
          name="Microsoft Teams"
          badge="Required"
          required
          description="Show news while you’re in a meeting and it hasn’t started yet—for example, while waiting for others to join."
          checked={teams}
          onChange={(v) => setPermissions({ teams: v })}
        />
        {!teams && (
          <p className="flex items-start gap-2 rounded-lg bg-orange-soft px-4 py-3 text-[13px] text-[#8a4a0b]" role="alert">
            <Info size={16} className="mt-0.5 shrink-0" aria-hidden />
            Teams access is required for the in-work experience. Cue only appears before a meeting starts, never during a discussion.
          </p>
        )}
        <PermissionRow
          icon={<ChromeIcon size={30} />}
          name="Chrome (Work)"
          badge="Optional"
          description="Allow Cue to appear on supported work sites and keep your preferences in sync."
          checked={chrome}
          onChange={(v) => setPermissions({ chrome: v })}
        />
        <p className="flex items-center gap-2 pt-2 text-[12.5px] text-muted">
          <Lock size={13} aria-hidden />
          Cue never reads meeting content, chat or audio. This prototype simulates these connections. No real access is requested.
        </p>
      </div>

      <div className="mt-10 flex flex-col-reverse items-center justify-between gap-3 sm:flex-row">
        <Button variant="ghost" onClick={() => goTo("setup-profile")}>
          <ArrowLeft size={16} aria-hidden /> Back
        </Button>
        <Button
          size="lg"
          className="w-full sm:w-auto sm:min-w-[260px]"
          disabled={!teams}
          onClick={() => {
            primeAudio();
            finishSetup();
          }}
        >
          Finish Setup <ArrowRight size={17} aria-hidden />
        </Button>
      </div>
    </SetupShell>
  );
}
