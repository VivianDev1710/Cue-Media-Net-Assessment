"use client";

import { ArrowRight, Clock } from "lucide-react";
import ProfileFields, { missingProfileFields } from "@/components/setup/ProfileFields";
import SetupShell from "@/components/setup/SetupShell";
import { Button } from "@/components/shared/ui";
import { useApp } from "@/lib/state";

export default function ProfileStep() {
  const { state, setProfile, goTo } = useApp();
  const missing = missingProfileFields(state.profile);
  const ready = missing.length === 0;

  return (
    <SetupShell step={1} label="Your profile">
      <h1 className="font-serif text-[32px] leading-tight font-semibold text-navy">Let’s personalise your news</h1>
      <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[15px] text-muted">
        <p>A few quick details to show you what matters.</p>
        <span className="inline-flex items-center gap-1.5 text-[12.5px]">
          <Clock size={13} aria-hidden /> Under a minute · change anytime in Settings
        </span>
      </div>
      <div className="mt-8">
        <ProfileFields profile={state.profile} onChange={setProfile} />
      </div>
      <div className="mt-10 flex flex-col items-center gap-2">
        <Button size="lg" className="w-full max-w-sm" disabled={!ready} onClick={() => goTo("setup-permissions")}>
          Continue <ArrowRight size={17} aria-hidden />
        </Button>
        <p className="h-4 text-[12px] text-muted" aria-live="polite">
          {ready ? "You can fine-tune all of this later in Settings." : `Add your ${missing.join(", ")} to continue.`}
        </p>
      </div>
    </SetupShell>
  );
}
