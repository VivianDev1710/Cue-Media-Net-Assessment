"use client";

import { Check, ChevronDown, Search } from "lucide-react";
import { useEffect, useId, useMemo, useRef, useState } from "react";
import type { Option } from "@/lib/taxonomy";

/** Accessible searchable dropdown (ARIA combobox + listbox). Type to filter, arrows to move, Enter to pick. */
export default function Combobox({
  id,
  label,
  placeholder,
  options,
  value,
  onChange,
}: {
  id: string;
  label: string;
  placeholder: string;
  options: Option[];
  value: string;
  onChange: (id: string) => void;
}) {
  const listId = useId();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [active, setActive] = useState(0);
  const wrapRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLUListElement>(null);
  const selected = options.find((o) => o.id === value);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return options;
    return options.filter((o) => o.label.toLowerCase().includes(q));
  }, [options, query]);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (!wrapRef.current?.contains(e.target as Node)) close();
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [open]);

  useEffect(() => {
    listRef.current?.querySelector<HTMLElement>(`[data-index="${active}"]`)?.scrollIntoView({ block: "nearest" });
  }, [active]);

  function openList() {
    setOpen(true);
    setQuery("");
    const idx = options.findIndex((o) => o.id === value);
    setActive(idx >= 0 ? idx : 0);
  }
  function close() {
    setOpen(false);
    setQuery("");
  }
  function pick(o: Option) {
    onChange(o.id);
    close();
    inputRef.current?.blur();
  }

  return (
    <div ref={wrapRef} className="relative">
      <label htmlFor={id} className="text-[13px] font-semibold text-navy">
        {label}
      </label>
      <div className="relative mt-1.5">
        {open && <Search size={15} className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-muted" aria-hidden />}
        <input
          ref={inputRef}
          id={id}
          role="combobox"
          aria-expanded={open}
          aria-controls={listId}
          aria-autocomplete="list"
          aria-activedescendant={open && filtered[active] ? `${listId}-${active}` : undefined}
          autoComplete="off"
          value={open ? query : (selected?.label ?? "")}
          placeholder={open ? `Search ${label.toLowerCase()}…` : placeholder}
          onFocus={openList}
          onClick={() => !open && openList()}
          onChange={(e) => {
            setQuery(e.target.value);
            setActive(0);
            if (!open) setOpen(true);
          }}
          onKeyDown={(e) => {
            if (e.key === "ArrowDown") {
              e.preventDefault();
              if (!open) openList();
              else setActive((a) => Math.min(a + 1, filtered.length - 1));
            } else if (e.key === "ArrowUp") {
              e.preventDefault();
              setActive((a) => Math.max(a - 1, 0));
            } else if (e.key === "Enter") {
              if (open && filtered[active]) {
                e.preventDefault();
                pick(filtered[active]);
              }
            } else if (e.key === "Escape") {
              close();
            } else if (e.key === "Tab") {
              close();
            }
          }}
          className={`h-11 w-full cursor-pointer rounded-lg border bg-white pr-9 text-[14px] text-navy placeholder:text-muted/80 focus:cursor-text focus:outline-none ${
            open ? "border-navy pl-9" : "border-line pl-3 hover:border-navy/40"
          }`}
        />
        <ChevronDown
          size={16}
          className={`pointer-events-none absolute top-1/2 right-3 -translate-y-1/2 text-muted transition-transform ${open ? "rotate-180" : ""}`}
          aria-hidden
        />
      </div>
      {open && (
        <ul
          ref={listRef}
          id={listId}
          role="listbox"
          aria-label={label}
          className="absolute z-30 mt-1 max-h-[264px] w-full animate-fade-in overflow-y-auto rounded-lg border border-line bg-white p-1 shadow-[0_16px_40px_-16px_rgba(23,36,58,0.35)]"
        >
          {filtered.length === 0 && <li className="px-3 py-2.5 text-[13px] text-muted">No matches for “{query}”</li>}
          {filtered.map((o, i) => (
            <li
              key={o.id}
              id={`${listId}-${i}`}
              data-index={i}
              role="option"
              aria-selected={o.id === value}
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => pick(o)}
              onMouseEnter={() => setActive(i)}
              className={`flex cursor-pointer items-center gap-2 rounded-md px-3 py-2 text-[13.5px] ${
                i === active ? "bg-ivory text-navy" : "text-navy"
              }`}
            >
              <span className="flex-1">{o.label}</span>
              {o.id === value && <Check size={15} className="text-teams" aria-hidden />}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
