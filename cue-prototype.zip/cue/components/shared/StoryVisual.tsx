"use client";

import {
  BatteryCharging,
  ChartColumn,
  Cpu,
  Factory,
  Fuel,
  Globe,
  Handshake,
  IndianRupee,
  Newspaper,
  type LucideIcon,
} from "lucide-react";
import type { Story } from "@/types/story";

/**
 * The content library ships without images, so each story gets an original,
 * generated editorial visual based on its subject. If a story has an `image`
 * field, that image is used instead.
 */
function pick(story: Story): { Icon: LucideIcon; hue: string } {
  const t = `${story.headline} ${story.category}`.toLowerCase();
  if (/\bai\b|semiconductor|data-centre|tech/.test(t)) return { Icon: Cpu, hue: "#2b3f63" };
  if (/cop|climate/.test(t)) return { Icon: Globe, hue: "#1f4d4a" };
  if (/steel|manufactur/.test(t)) return { Icon: Factory, hue: "#3b3a4f" };
  if (/rupee|bond|inflow/.test(t)) return { Icon: IndianRupee, hue: "#2f3d5c" };
  if (/trade|agreement|fta/.test(t)) return { Icon: Handshake, hue: "#3a3358" };
  if (/oil|gas|import bill/.test(t)) return { Icon: Fuel, hue: "#4a3a2e" };
  if (/solar|battery|storage/.test(t)) return { Icon: BatteryCharging, hue: "#1f4a3a" };
  if (/pmi|growth|economy/.test(t)) return { Icon: ChartColumn, hue: "#26405a" };
  return { Icon: Newspaper, hue: "#17243a" };
}

export default function StoryVisual({ story, className = "", iconSize = 40 }: { story: Story; className?: string; iconSize?: number }) {
  if (story.image) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={story.image} alt="" className={`object-cover ${className}`} />;
  }
  const { Icon, hue } = pick(story);
  return (
    <div
      className={`relative overflow-hidden ${className}`}
      style={{ background: `linear-gradient(135deg, ${hue} 0%, #17243a 100%)` }}
      aria-hidden
    >
      <svg className="absolute inset-0 h-full w-full opacity-[0.18]" preserveAspectRatio="none" viewBox="0 0 100 60">
        {Array.from({ length: 9 }).map((_, i) => (
          <line key={i} x1={i * 13 - 20} y1="60" x2={i * 13 + 20} y2="0" stroke="#fff" strokeWidth="0.4" />
        ))}
      </svg>
      <div className="absolute -right-3 -bottom-4 h-12 w-12 rounded-full bg-orange/70" />
      <div className="absolute inset-0 flex items-center justify-center">
        <Icon size={iconSize} strokeWidth={1.4} className="text-white/90" />
      </div>
    </div>
  );
}
