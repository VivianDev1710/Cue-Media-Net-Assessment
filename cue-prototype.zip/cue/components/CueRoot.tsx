"use client";

import { useEffect } from "react";
import CueApp from "@/components/app/CueApp";
import MeetingEnded from "@/components/meeting/MeetingEnded";
import MeetingInvite from "@/components/meeting/MeetingInvite";
import MeetingScreen from "@/components/meeting/MeetingScreen";
import PermissionsStep from "@/components/setup/PermissionsStep";
import ProfileStep from "@/components/setup/ProfileStep";
import SetupComplete from "@/components/setup/SetupComplete";
import DemoPanel from "@/components/shared/DemoPanel";
import Toasts from "@/components/shared/Toasts";
import { contentError, library } from "@/lib/content";
import { MEETING } from "@/lib/constants";
import { AppProvider, useApp } from "@/lib/state";

/** Adds the second participant MEETING.participantDelayMs (30s) after joining — runs even while the user is reading. */
function ParticipantScheduler() {
  const { state, participantJoin, toast } = useApp();
  const { joinedAt, participantJoinedAt } = state.meeting;
  const inMeeting = state.stage === "meeting";

  useEffect(() => {
    if (!inMeeting || !joinedAt || participantJoinedAt) return;
    const wait = Math.max(0, joinedAt + MEETING.participantDelayMs - Date.now());
    const t = setTimeout(() => {
      participantJoin();
      toast(`${MEETING.participantName} joined the meeting`, "dark");
    }, wait);
    return () => clearTimeout(t);
  }, [inMeeting, joinedAt, participantJoinedAt, participantJoin, toast]);

  return null;
}

function Screens() {
  const { state } = useApp();
  switch (state.stage) {
    case "setup-profile":
      return <ProfileStep />;
    case "setup-permissions":
      return <PermissionsStep />;
    case "setup-complete":
      return <SetupComplete />;
    case "meeting":
      return state.reader.open ? <CueApp /> : <MeetingScreen />;
    case "meeting-ended":
      return <MeetingEnded />;
    case "home":
    default:
      return <CueApp />;
  }
}

function Shell() {
  const { state } = useApp();
  return (
    <>
      <Screens />
      {state.inviteVisible && state.stage !== "meeting" && <MeetingInvite />}
      <ParticipantScheduler />
      <Toasts />
      <DemoPanel />
    </>
  );
}

function ContentErrorScreen({ message }: { message: string }) {
  return (
    <main className="mx-auto max-w-xl px-6 py-24 font-mono text-[14px] text-navy">
      <p className="text-[12px] font-semibold tracking-widest text-[#b42318] uppercase">Developer error · content library</p>
      <h1 className="mt-2 font-sans text-2xl font-semibold">Cue couldn’t load today’s stories</h1>
      <p className="mt-4 rounded-lg bg-white p-4 ring-1 ring-line">{message}</p>
      <p className="mt-4 text-muted">
        Place the daily Markdown at <code>data/cue_news_today.md</code> and run <code>npm run build-content</code>.
      </p>
      {library.warnings.length > 0 && (
        <ul className="mt-4 list-disc pl-5 text-muted">
          {library.warnings.map((w) => (
            <li key={w}>{w}</li>
          ))}
        </ul>
      )}
    </main>
  );
}

export default function CueRoot() {
  if (contentError) return <ContentErrorScreen message={contentError} />;
  return (
    <AppProvider>
      <Shell />
    </AppProvider>
  );
}
