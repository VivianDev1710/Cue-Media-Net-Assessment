"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { stories } from "@/lib/content";
import { MEETING } from "@/lib/constants";
import { LOGO_SRC } from "@/lib/logo";
import { DEMO_PROFILE } from "@/lib/demo-controls";
import { functionById, INDUSTRIES, LEGACY_ROLE_TO_FUNCTION, MAX_TOPICS, SENIORITY } from "@/lib/taxonomy";
import { clearKey, isStringArray, loadJSON, saveJSON, STORAGE_KEY } from "@/lib/storage";
import { buildQueue, nextAfter, todayKey } from "@/lib/story-queue";
import type { Story } from "@/types/story";

export type Stage = "setup-profile" | "setup-permissions" | "setup-complete" | "home" | "meeting" | "meeting-ended";
export type ReaderScreen = "brief" | "deep" | "saved" | "settings";

export interface Profile {
  name: string;
  function: string; // id from FUNCTIONS
  seniority: string;
  industry: string;
  /** Unified "What matters to your work?" selection: broad themes + specific topics, max 6 */
  topics: string[];
  interests: string[];
  /** true once the user adds/removes a topic; until then topics follow the suggestions */
  topicsCustomised: boolean;
}

export interface MeetingState {
  joinedAt: number | null;
  participantJoinedAt: number | null;
  leftAt: number | null;
  raised: boolean;
}

export interface Reader {
  open: boolean;
  screen: ReaderScreen;
  storyId: string | null;
  simplified: boolean;
}

export interface AppState {
  version: 1;
  stage: Stage;
  setupCompleted: boolean;
  profile: Profile;
  permissions: { teams: boolean; chrome: boolean };
  inviteVisible: boolean;
  meeting: MeetingState;
  reader: Reader;
  readIds: string[];
  savedIds: string[];
  snoozedIds: string[];
  hiddenToday: Record<string, string>;
  notInterestedIds: string[];
  pinnedStoryId: string | null;
  cardCollapsed: boolean;
  soundOn: boolean;
}

const EMPTY_MEETING: MeetingState = { joinedAt: null, participantJoinedAt: null, leftAt: null, raised: false };

export const DEFAULT_STATE: AppState = {
  version: 1,
  stage: "setup-profile",
  setupCompleted: false,
  profile: { name: "", function: "", seniority: "", industry: "", topics: [], interests: [], topicsCustomised: false },
  permissions: { teams: true, chrome: false },
  inviteVisible: false,
  meeting: EMPTY_MEETING,
  reader: { open: false, screen: "brief", storyId: null, simplified: false },
  readIds: [],
  savedIds: [],
  snoozedIds: [],
  hiddenToday: {},
  notInterestedIds: [],
  pinnedStoryId: null,
  cardCollapsed: false,
  soundOn: true,
};

const STAGES: Stage[] = ["setup-profile", "setup-permissions", "setup-complete", "home", "meeting", "meeting-ended"];
const SCREENS: ReaderScreen[] = ["brief", "deep", "saved", "settings"];
const validIds = new Set(stories.map((s) => s.id));
const ids = (v: unknown) => (isStringArray(v) ? v.filter((x) => validIds.has(x)) : []);

/** Merge stored data with defaults, discarding anything malformed. */
function hydrate(raw: Partial<AppState> | null): AppState {
  if (!raw || raw.version !== 1) return DEFAULT_STATE;
  const d = DEFAULT_STATE;
  const p = (raw.profile ?? {}) as Partial<Profile> & { role?: string; priorities?: string[] };
  const m = (raw.meeting ?? {}) as Partial<MeetingState>;
  const r = (raw.reader ?? {}) as Partial<Reader>;
  const num = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? v : null);
  const state: AppState = {
    ...d,
    stage: STAGES.includes(raw.stage as Stage) ? (raw.stage as Stage) : d.stage,
    setupCompleted: raw.setupCompleted === true,
    profile: {
      name: typeof p.name === "string" ? p.name : "",
      function:
        typeof p.function === "string" && functionById(p.function)
          ? p.function
          : typeof p.role === "string"
            ? (LEGACY_ROLE_TO_FUNCTION[p.role] ?? "")
            : "",
      seniority: typeof p.seniority === "string" && SENIORITY.some((x) => x.id === p.seniority) ? p.seniority : "",
      industry: typeof p.industry === "string" && INDUSTRIES.some((x) => x.id === p.industry) ? p.industry : "",
      // Earlier versions kept priorities separately: merge them into the unified selection (deduplicated, max 6)
      topics: Array.from(new Set([...(isStringArray(p.priorities) ? p.priorities : []), ...(isStringArray(p.topics) ? p.topics : [])])).slice(0, MAX_TOPICS),
      interests: isStringArray(p.interests) ? p.interests : [],
      topicsCustomised: p.topicsCustomised === true,
    },
    permissions: {
      teams: raw.permissions?.teams !== false,
      chrome: raw.permissions?.chrome === true,
    },
    inviteVisible: raw.inviteVisible === true,
    meeting: {
      joinedAt: num(m.joinedAt),
      participantJoinedAt: num(m.participantJoinedAt),
      leftAt: num(m.leftAt),
      raised: m.raised === true,
    },
    reader: {
      open: r.open === true,
      screen: SCREENS.includes(r.screen as ReaderScreen) ? (r.screen as ReaderScreen) : "brief",
      storyId: typeof r.storyId === "string" && validIds.has(r.storyId) ? r.storyId : null,
      simplified: r.simplified === true,
    },
    readIds: ids(raw.readIds),
    savedIds: ids(raw.savedIds),
    snoozedIds: ids(raw.snoozedIds),
    notInterestedIds: ids(raw.notInterestedIds),
    hiddenToday:
      raw.hiddenToday && typeof raw.hiddenToday === "object"
        ? Object.fromEntries(Object.entries(raw.hiddenToday).filter(([k, v]) => validIds.has(k) && typeof v === "string"))
        : {},
    pinnedStoryId: typeof raw.pinnedStoryId === "string" && validIds.has(raw.pinnedStoryId) ? raw.pinnedStoryId : null,
    cardCollapsed: raw.cardCollapsed === true,
    soundOn: raw.soundOn !== false,
  };
  // Guard against impossible combinations after refresh
  if (!state.setupCompleted && !state.stage.startsWith("setup")) state.stage = "setup-profile";
  // Older saves (role-based) lack seniority: send them back through setup with their answers kept
  if (state.setupCompleted && (!state.profile.function || !state.profile.seniority || !state.profile.industry)) {
    state.setupCompleted = false;
    state.stage = "setup-profile";
    state.inviteVisible = false;
  }
  if (state.stage === "meeting" && !state.meeting.joinedAt) state.stage = "home";
  return state;
}

export interface Toast {
  id: number;
  text: string;
  tone?: "light" | "dark";
}

interface Ctx {
  state: AppState;
  queue: Story[];
  toasts: Toast[];
  toast: (text: string, tone?: "light" | "dark") => void;
  setProfile: (patch: Partial<Profile>) => void;
  setPermissions: (patch: Partial<AppState["permissions"]>) => void;
  goTo: (stage: Stage) => void;
  finishSetup: () => void;
  showInvite: () => void;
  dismissInvite: () => void;
  joinMeeting: () => void;
  leaveMeeting: () => void;
  participantJoin: () => void;
  toggleRaise: () => void;
  returnToCue: () => void;
  openStory: (id: string, screen?: "brief" | "deep") => void;
  openScreen: (screen: ReaderScreen) => void;
  closeReader: () => void;
  setSimplified: (v: boolean) => void;
  markReadAndNext: (id: string, from: "card" | "reader") => void;
  notNow: (id: string) => void;
  hideToday: (id: string) => void;
  setCardCollapsed: (v: boolean) => void;
  toggleSave: (id: string) => void;
  notInterested: (id: string) => void;
  setSound: (v: boolean) => void;
  reset: () => void;
  demoSkipSetup: () => void;
  demoJumpToStory: (id: string) => void;
}

const AppContext = createContext<Ctx | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppState>(DEFAULT_STATE);
  const [hydrated, setHydrated] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const toastId = useRef(0);

  useEffect(() => {
    setState(hydrate(loadJSON<AppState>(STORAGE_KEY)));
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) saveJSON(STORAGE_KEY, state);
  }, [state, hydrated]);

  const update = useCallback((fn: (s: AppState) => AppState) => setState(fn), []);

  const toast = useCallback((text: string, tone: "light" | "dark" = "light") => {
    const id = ++toastId.current;
    setToasts((t) => [...t, { id, text, tone }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3600);
  }, []);

  const queue = useMemo(() => buildQueue(stories, state), [state]);

  const actions = useMemo(() => {
    const setProfile = (patch: Partial<Profile>) => update((s) => ({ ...s, profile: { ...s.profile, ...patch } }));
    const setPermissions = (patch: Partial<AppState["permissions"]>) =>
      update((s) => ({ ...s, permissions: { ...s.permissions, ...patch } }));
    const goTo = (stage: Stage) => update((s) => ({ ...s, stage }));
    const finishSetup = () => update((s) => ({ ...s, setupCompleted: true, stage: "setup-complete", inviteVisible: false }));
    const showInvite = () => update((s) => ({ ...s, inviteVisible: true }));
    const dismissInvite = () =>
      update((s) => ({
        ...s,
        inviteVisible: false,
        stage: s.stage === "meeting" ? s.stage : "home",
        reader: { ...s.reader, open: true, screen: "brief", storyId: s.reader.storyId },
      }));
    const joinMeeting = () =>
      update((s) => ({
        ...s,
        stage: "meeting",
        inviteVisible: false,
        cardCollapsed: false,
        meeting: { ...EMPTY_MEETING, joinedAt: Date.now() },
        reader: { ...s.reader, open: false },
      }));
    const leaveMeeting = () =>
      update((s) => ({ ...s, stage: "meeting-ended", meeting: { ...s.meeting, leftAt: Date.now() }, reader: { ...s.reader, open: false } }));
    const participantJoin = () =>
      update((s) =>
        s.stage === "meeting" && !s.meeting.participantJoinedAt
          ? { ...s, meeting: { ...s.meeting, participantJoinedAt: Date.now() } }
          : s,
      );
    const toggleRaise = () => update((s) => ({ ...s, meeting: { ...s.meeting, raised: !s.meeting.raised } }));
    const returnToCue = () =>
      update((s) => ({ ...s, stage: "home", reader: { ...s.reader, open: true, screen: "brief" } }));
    const openStory = (id: string, screen: "brief" | "deep" = "brief") =>
      update((s) => ({
        ...s,
        reader: { open: true, screen, storyId: id, simplified: s.reader.storyId === id ? s.reader.simplified : false },
      }));
    const openScreen = (screen: ReaderScreen) =>
      update((s) => ({ ...s, reader: { ...s.reader, open: true, screen } }));
    const closeReader = () => update((s) => ({ ...s, reader: { ...s.reader, open: false } }));
    const setSimplified = (v: boolean) => update((s) => ({ ...s, reader: { ...s.reader, simplified: v } }));
    const markReadAndNext = (id: string, from: "card" | "reader") =>
      update((s) => {
        const base: AppState = {
          ...s,
          readIds: s.readIds.includes(id) ? s.readIds : [...s.readIds, id],
          snoozedIds: s.snoozedIds.filter((x) => x !== id),
          pinnedStoryId: s.pinnedStoryId === id ? null : s.pinnedStoryId,
        };
        if (from === "card") return base;
        const next = nextAfter(stories, id, base);
        return { ...base, reader: { open: true, screen: "brief", storyId: next?.id ?? null, simplified: false } };
      });
    const notNow = (id: string) =>
      update((s) => {
        const snoozedIds = [...s.snoozedIds.filter((x) => x !== id), id];
        const remaining = buildQueue(stories, { ...s, snoozedIds, pinnedStoryId: null });
        return {
          ...s,
          snoozedIds,
          pinnedStoryId: s.pinnedStoryId === id ? null : s.pinnedStoryId,
          cardCollapsed: remaining.length <= 1,
        };
      });
    const hideToday = (id: string) =>
      update((s) => ({
        ...s,
        hiddenToday: { ...s.hiddenToday, [id]: todayKey() },
        pinnedStoryId: s.pinnedStoryId === id ? null : s.pinnedStoryId,
      }));
    const setCardCollapsed = (v: boolean) => update((s) => ({ ...s, cardCollapsed: v }));
    const toggleSave = (id: string) =>
      update((s) => ({
        ...s,
        savedIds: s.savedIds.includes(id) ? s.savedIds.filter((x) => x !== id) : [id, ...s.savedIds],
      }));
    const notInterested = (id: string) =>
      update((s) => ({ ...s, notInterestedIds: s.notInterestedIds.includes(id) ? s.notInterestedIds : [...s.notInterestedIds, id] }));
    const setSound = (v: boolean) => update((s) => ({ ...s, soundOn: v }));
    const reset = () => {
      clearKey(STORAGE_KEY);
      setState(DEFAULT_STATE);
    };
    const demoSkipSetup = () =>
      update((s) => ({
        ...s,
        profile: { ...DEMO_PROFILE, topicsCustomised: false },
        permissions: { teams: true, chrome: false },
        setupCompleted: true,
        stage: "setup-complete",
        inviteVisible: false,
      }));
    const demoJumpToStory = (id: string) =>
      update((s) => ({
        ...s,
        pinnedStoryId: id,
        readIds: s.readIds.filter((x) => x !== id),
        hiddenToday: Object.fromEntries(Object.entries(s.hiddenToday).filter(([k]) => k !== id)),
        cardCollapsed: false,
        reader: { open: true, screen: "brief", storyId: id, simplified: false },
        stage: s.setupCompleted ? (s.stage === "meeting" ? "meeting" : "home") : s.stage,
      }));
    return {
      setProfile, setPermissions, goTo, finishSetup, showInvite, dismissInvite, joinMeeting, leaveMeeting,
      participantJoin, toggleRaise, returnToCue, openStory, openScreen, closeReader, setSimplified,
      markReadAndNext, notNow, hideToday, setCardCollapsed, toggleSave, notInterested, setSound,
      reset, demoSkipSetup, demoJumpToStory,
    };
  }, [update]);

  const value = useMemo<Ctx>(() => ({ state, queue, toasts, toast, ...actions }), [state, queue, toasts, toast, actions]);

  if (!hydrated) {
    return (
      <div className="flex h-screen items-center justify-center bg-ivory text-muted" aria-busy="true">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={LOGO_SRC} alt="cue." style={{ height: 30, width: "auto" }} className="animate-fade-in" />
      </div>
    );
  }
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): Ctx {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}

/** Ticking clock for timers (1s). */
export function useNow(intervalMs = 1000): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "VJ";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export function formatElapsed(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return h ? `${h}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
}
