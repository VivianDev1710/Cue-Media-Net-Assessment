"use client";

import { Check, Plus, Search, X } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { countItems, type CatalogGroup } from "@/lib/taxonomy";

/** Searchable catalogue of topics or interests. Selections apply immediately, capped at `max`. */
export default function ExploreDialog({
  title,
  noun,
  catalog,
  selected,
  max,
  onToggle,
  onClose,
  allowCustom = true,
}: {
  title: string;
  noun: string; // "topics" | "interests"
  catalog: CatalogGroup[];
  selected: string[];
  max: number;
  onToggle: (item: string) => void;
  onClose: () => void;
  allowCustom?: boolean;
}) {
  const [query, setQuery] = useState("");
  const [group, setGroup] = useState<string>("All");
  const inputRef = useRef<HTMLInputElement>(null);
  const total = countItems(catalog);
  const full = selected.length >= max;

  useEffect(() => {
    inputRef.current?.focus();
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [onClose]);

  const q = query.trim().toLowerCase();
  const groups = useMemo(() => {
    return catalog
      .filter((g) => group === "All" || g.group === group || q)
      .map((g) => ({ group: g.group, items: q ? g.items.filter((i) => i.toLowerCase().includes(q)) : g.items }))
      .filter((g) => g.items.length);
  }, [catalog, group, q]);
  const matches = groups.reduce((n, g) => n + g.items.length, 0);
  const exact = catalog.some((g) => g.items.some((i) => i.toLowerCase() === q));
  const custom = query.trim().replace(/\s+/g, " ");
  const customSelected = selected.filter((s) => !catalog.some((g) => g.items.includes(s)));

  const chip = (item: string) => {
    const on = selected.includes(item);
    return (
      <button
        key={item}
        type="button"
        role="checkbox"
        aria-checked={on}
        disabled={!on && full}
        onClick={() => onToggle(item)}
        className={`inline-flex items-center gap-1.5 rounded-md border px-3 py-1.5 text-[13px] font-medium transition-colors ${
          on ? "border-navy bg-navy text-white" : "border-line bg-white text-navy hover:border-navy/40 disabled:cursor-not-allowed disabled:opacity-40"
        }`}
      >
        {on ? <Check size={13} strokeWidth={2.5} aria-hidden /> : <Plus size={13} aria-hidden className="text-muted" />}
        {item}
      </button>
    );
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-end justify-center bg-navy/40 p-0 backdrop-blur-[2px] sm:items-center sm:p-6" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="explore-title"
        className="flex max-h-[88vh] w-full max-w-[760px] animate-rise flex-col overflow-hidden rounded-t-2xl bg-white shadow-2xl sm:rounded-2xl"
      >
        <header className="border-b border-line px-5 pt-5 pb-4 sm:px-6">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h2 id="explore-title" className="font-serif text-[22px] font-semibold text-navy">
                {title}
              </h2>
              <p className="mt-0.5 text-[13px] text-muted">
                Search {total}+ {noun}. Pick up to {max}.
              </p>
            </div>
            <button type="button" onClick={onClose} aria-label="Close" className="rounded-md p-1.5 text-muted hover:bg-ivory hover:text-navy">
              <X size={18} />
            </button>
          </div>
          <div className="relative mt-4">
            <Search size={16} className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-muted" aria-hidden />
            <input
              ref={inputRef}
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={noun === "topics" ? "Try “semiconductors”, “tariffs” or “Indian FMCG”" : "Try “cricket”, “space” or “architecture”"}
              aria-label={`Search ${noun}`}
              className="h-11 w-full rounded-lg border border-line bg-ivory/60 pr-3 pl-9 text-[14px] text-navy focus:border-navy focus:bg-white focus:outline-none"
            />
          </div>
          {!q && (
            <div className="-mx-1 mt-3 flex gap-1.5 overflow-x-auto px-1 pb-1 [scrollbar-width:thin]" role="tablist" aria-label="Categories">
              {["All", ...catalog.map((g) => g.group)].map((g) => (
                <button
                  key={g}
                  type="button"
                  role="tab"
                  aria-selected={group === g}
                  onClick={() => setGroup(g)}
                  className={`shrink-0 rounded-full px-3 py-1 text-[12.5px] font-medium ${
                    group === g ? "bg-[#eceaf6] text-navy" : "text-muted hover:bg-ivory hover:text-navy"
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          )}
        </header>

        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4 sm:px-6">
          {q && (
            <p className="mb-3 text-[12.5px] text-muted" aria-live="polite">
              {matches} {matches === 1 ? "match" : "matches"}
            </p>
          )}
          {customSelected.length > 0 && !q && (
            <section className="mb-5">
              <h3 className="mb-2 text-[12px] font-semibold text-muted">Added by you</h3>
              <div className="flex flex-wrap gap-2">{customSelected.map(chip)}</div>
            </section>
          )}
          {groups.map((g) => (
            <section key={g.group} className="mb-5">
              <h3 className="mb-2 text-[12px] font-semibold text-muted">{g.group}</h3>
              <div className="flex flex-wrap gap-2">{g.items.map(chip)}</div>
            </section>
          ))}
          {q && allowCustom && !exact && custom.length > 1 && (
            <button
              type="button"
              disabled={full || selected.includes(custom)}
              onClick={() => {
                onToggle(custom);
                setQuery("");
              }}
              className="inline-flex items-center gap-2 rounded-lg border border-dashed border-navy/40 px-3 py-2 text-[13px] font-semibold text-navy hover:bg-ivory disabled:opacity-40"
            >
              <Plus size={14} aria-hidden /> Follow “{custom}”
            </button>
          )}
          {q && matches === 0 && !allowCustom && <p className="text-[13px] text-muted">Nothing matches “{query}”.</p>}
        </div>

        <footer className="flex items-center gap-3 border-t border-line bg-ivory/50 px-5 py-3 sm:px-6">
          <div className="min-w-0 flex-1 text-[12.5px] text-muted" aria-live="polite">
            <span className="font-semibold text-navy">
              {selected.length} of {max}
            </span>{" "}
            selected{full ? " · remove one to add another" : ""}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex h-10 items-center rounded-lg bg-navy px-5 text-[14px] font-semibold text-white hover:bg-navy-2"
          >
            Done
          </button>
        </footer>
      </div>
    </div>
  );
}
