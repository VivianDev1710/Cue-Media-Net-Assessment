# Cue prototype: acceptance criteria

These criteria cover the November 23 iteration. Every item can be verified in the browser without developer tools unless noted. Timings are measured from the moment **Join** is clicked.

---

## 0. Brand

| # | Criterion | Pass condition |
|---|---|---|
| 0.1 | The supplied **cue.** wordmark (navy letters, orange dot) is the only logo used | It appears on setup steps 1–2, "You're all set", the in-meeting cue card, the collapsed pill, the app sidebar and the loading screen, with no text-rendered logo anywhere |
| 0.2 | Dark surfaces use the white variant | "You left the meeting" shows white letters with an orange dot |
| 0.3 | The favicon uses the wordmark | Browser tab shows the cue. icon |

## 1. Cue card summaries

| # | Criterion | Pass condition |
|---|---|---|
| 1.1 | Each cue card shows a **summary of the whole article**, not an excerpt | Card text matches the story's `### Cue card summary` field in `data/cue_news_today.md`, not its opening paragraph |
| 1.2 | Summary length | 200–230 characters (31–38 words); at desktop widths (≥1280px) it wraps to **2–3 lines** |
| 1.3 | Self-contained | Each summary states what happened **and** why it matters / what to do, without needing the headline |
| 1.4 | No truncation | No ellipsis or line clamp on the summary |
| 1.5 | Fallback | If a story has no `Cue card summary`, the card shows the `20-second cue` text and `npm run build-content` prints a warning |

## 2. Minimise (×) on the cue card

| # | Criterion | Pass condition |
|---|---|---|
| 2.1 | A × button sits in the card's top-right corner | Visible on every story card; accessible name "Minimise Cue"; keyboard-focusable |
| 2.2 | Clicking × minimises, it does not dismiss | Card collapses into the existing pill ("cue. · N stories waiting · Show"); the story is **not** marked read, snoozed or hidden |
| 2.3 | Restore | Clicking **Show** brings back the same story card |
| 2.4 | Existing actions unchanged | Know more, Mark as read & next, Not now, Save and ••• (Don't show this today / Minimise) still work |

## 3. Meeting simulation timings

| # | Criterion | Pass condition |
|---|---|---|
| 3.1 | No card on entry | At 0–1.9s after Join, only the meeting (avatar, "Waiting for others to join…") is visible |
| 3.2 | Card appears at **2s** | At 2.0s (±0.3s) the card slides up about 28px while fading in over **360ms** with an ease-out curve (`cubic-bezier(0.22, 1, 0.36, 1)`), with no bounce, scale or halo; it lands in its usual position and size |
| 3.2a | Consistent entrance | The same entrance plays on every join, rejoin and after any reset; later story changes within a meeting use the standard subtle rise |
| 3.3 | Layout is stable | The avatar and waiting text do not jump when the card appears (space is reserved) |
| 3.4 | Second participant at **30s** | At 30s (±1s) Alex Morgan joins (camera and mic off); "No one has started speaking yet." appears above the card; a dark toast announces the join |
| 3.5 | Joining while reading | If the brief or deep dive is open at 30s, reading is not interrupted; the meeting banner updates to "Alex Morgan joined · No one has started speaking yet." |
| 3.6 | Repeatable | Leave → Rejoin, Reset, or a new journey restarts both timers from zero, with the same 2s and 30s results every time; there is no persisted timer override |
| 3.7 | Refresh-safe | Refreshing mid-meeting keeps the elapsed time; if past 2s the card shows immediately, and if past 30s the participant is present |
| 3.8 | Demo override | Demo controls (Shift + D) can still add the participant immediately; this does not change the default timings |

## 4. "You're all set" screen

| # | Criterion | Pass condition |
|---|---|---|
| 4.1 | Instruction line | Screen shows "Join the dummy Teams meeting to experience Cue." prominently under the subtitle |
| 4.2 | Invitation hint | A secondary line says the invitation is on its way, then that it is in the bottom-right corner once it appears (after 2s) |
| 4.3 | Restart button | A "Go to beginning of user journey" button is visible on this screen |
| 4.4 | Full reset | Clicking it returns to **Step 1 of 2 · Your profile** with every field empty (name, function, seniority, industry, topics, interests), Teams toggle back to its default, no invitation, no meeting, no timers, no participant, no read/saved/snoozed/hidden stories and the card un-minimised; refreshing afterwards stays at step 1 |

## 5. Unified "What matters to your work?"

The detailed flow is in *Unified topic-selection flow* below.

| # | Criterion | Pass condition |
|---|---|---|
| 5.1 | One section | There is no separate "Business priorities" or "Suggested topics" section; both live in **What matters to your work?** |
| 5.2 | Limit of **6** | Counter shows n/6; when 6 are chosen, add options are hidden and the message "All 6 chosen — remove one to see more suggestions." appears; the Explore dialog shows "6 of 6 selected" and disables unselected items |
| 5.3 | Smart pre-selection | After function **and** industry are chosen, 4 items are pre-selected: the function's broad theme plus the top 3 role topics (industry-specific first) |
| 5.4 | No duplicates | An item never appears twice: anything selected is removed from the "More for your role" and "Broader themes" rows, and themes and topics have distinct names |
| 5.5 | Customise | Users can remove any item (×), add from "More for your role", add from "Broader themes", or search **Explore more topics (136+)**, which includes a "Broad themes" group; custom topics can be followed by name |
| 5.6 | Follows role until edited | Changing function or industry refreshes the pre-selection until the user adds or removes anything; then "Reset to suggestions" appears |
| 5.7 | Required | Continue is enabled only with function, seniority, industry and at least 1 selection |
| 5.8 | Personal interests unchanged | Separate optional panel, 7 examples, Explore more interests (105+), up to 5 |
| 5.9 | Migration | A browser with an older saved profile has its old priorities merged into the selection (deduplicated, maximum 6) |
| 5.10 | Settings parity | Settings → Profile shows the same unified section with the same rules |

## 6. Reset prototype in navigation

| # | Criterion | Pass condition |
|---|---|---|
| 6.1 | Sidebar item | "Reset prototype" appears in the left navigation under Settings (and in the compact top bar on smaller screens) |
| 6.2 | Confirmation | Clicking opens a dialog ("Start the journey again?") with Cancel and Reset prototype; Esc or a click outside cancels |
| 6.3 | Same reset as 4.4 | Confirming returns to setup step 1 with everything cleared |
| 6.4 | Still in Settings | Settings → Prototype → Reset prototype still works with its inline confirmation |

## Regression checks (unchanged features)

- Teams permission step: Teams required, Chrome optional, Finish Setup → "You're all set" → invite after 2s with optional chime.
- Brief: Too technical toggle, Not interested, Save, Deep dive · 10 min, Mark as read & next.
- Deep dive: section list follows scroll, click-to-jump, Cue analysis labels, persona view.
- Saved, Settings, Leave → meeting ended → Return to Cue / Rejoin, demo controls.

---

## Unified topic-selection flow

**Goal:** one cohesive, roughly 20-second decision about *what matters to your work*, combining broad work themes and specific role-relevant topics under a single limit of 6.

### Building blocks

- **Broad themes (8):** Growth & competition · Technology & AI · Customers & markets · Strategy & transformation · Regulation & policy · Talent & leadership · Supply chain & operations · Finance & investment.
- **Specific topics (128)** in 10 groups, such as Semiconductors, Indian FMCG, Competitor launches, and Trade deals & tariffs.
- **Explore catalogue** = Broad themes (8) + specific topics (128) = 136.
- **Role signals:** function → 1 theme plus 5 function topics; industry → 2 industry topics. Rules live in `lib/taxonomy.ts` (`suggestTheme`, `suggestTopics`, `defaultSelection`).

### States

1. **Before role is known** (function or industry missing)
   - Helper text: "Pick up to 6. Add your function and industry for suggestions tailored to your role."
   - Shows the "Broader themes" add-chips and Explore. Users can already pick.
2. **Role known, untouched** (function and industry set, `topicsCustomised = false`)
   - The selection is auto-filled with **4** items: function theme + top 3 role topics (industry-specific first, deduplicated). Example: Finance & Investment in FMCG → Finance & investment, Indian FMCG, Rural consumption, Interest rates & central banks.
   - Selected chips show a small sparkle to mark them as suggestions.
   - Below: **More for your role** (the remaining role topics, usually 2) and **Broader themes** (the 7 themes not selected), both as dashed "+ add" chips.
   - Two free slots invite the user to personalise.
   - Changing function or industry recalculates the 4 suggestions.
3. **Customised** (user added or removed anything)
   - Selection is frozen against role changes.
   - "Reset to suggestions" restores the 4-item default for the current role.
4. **Full** (6/6)
   - Add rows are hidden to reduce noise.
   - Counter turns amber with the message "All 6 chosen — remove one to see more suggestions."
   - Explore disables unselected items.

### Rules

- One list (`profile.topics`), one cap (6), and order of selection preserved.
- No item appears in two places at once: selected items leave the add rows, and theme names are distinct from topic names.
- Searching in Explore covers themes and topics together; free-text "Follow '…'" adds a custom topic (counted in the 6).
- Minimum 1 selection to continue.
- The selection drives the "You follow …" relevance label in briefs. Persona views are driven by function, not by topics.

### Copy

| Element | Text |
|---|---|
| Section title | What matters to your work? |
| Helper (role known) | We've started you off for {Function} in {Industry}. Keep, remove or add — up to 6. |
| Helper (role unknown) | Pick up to 6. Add your function and industry for suggestions tailored to your role. |
| Row labels | More for your role · Broader themes |
| Explore button | Explore more topics (136+) |
| Full | All 6 chosen — remove one to see more suggestions. |
| Footer under Continue | You can fine-tune all of this later in Settings. |
