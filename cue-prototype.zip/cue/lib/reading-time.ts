import { READING_WPM } from "@/lib/constants";
import type { Story } from "@/types/story";

const words = (s: string) => s.split(/\s+/).filter(Boolean).length;

/** Honest estimate: every word shown on the deep-dive page (sections + all persona views) at READING_WPM. */
export function deepDiveWords(story: Story): number {
  return (
    story.deepDive.reduce((n, s) => n + words(s.body), 0) +
    story.personaImplications.reduce((n, p) => n + words(p.body), 0)
  );
}

export function deepDiveMinutes(story: Story): number {
  return Math.max(1, Math.round(deepDiveWords(story) / READING_WPM));
}
