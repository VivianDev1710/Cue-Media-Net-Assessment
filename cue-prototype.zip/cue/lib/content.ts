import raw from "@/data/stories.json";
import type { ContentLibrary, Story } from "@/types/story";

function load(): { library: ContentLibrary | null; error: string | null } {
  try {
    const lib = raw as unknown as ContentLibrary;
    if (!lib || !Array.isArray(lib.stories)) {
      return { library: null, error: "data/stories.json is malformed: no `stories` array. Run `npm run build-content`." };
    }
    if (lib.stories.length === 0) {
      return { library: lib, error: "The content library has no full stories. Check data/cue_news_today.md and run `npm run build-content`." };
    }
    return { library: lib, error: null };
  } catch (e) {
    return { library: null, error: `Could not load content library: ${(e as Error).message}` };
  }
}

const loaded = load();

export const contentError = loaded.error;
export const library: ContentLibrary = loaded.library ?? {
  meta: { date: "", generatedAt: "", builtAt: "" },
  stories: [],
  backups: [],
  interactionCopy: {},
  warnings: [],
};
export const stories: Story[] = [...library.stories].sort((a, b) => a.rank - b.rank);
const byId = new Map(stories.map((s) => [s.id, s]));

export function getStory(id: string | null | undefined): Story | undefined {
  return id ? byId.get(id) : undefined;
}

export function copy(key: string, fallback: string): string {
  return library.interactionCopy?.[key] || fallback;
}
