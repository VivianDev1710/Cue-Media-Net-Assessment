"use client";

import { ArrowLeft, ArrowRight, BookOpen, Check, CircleCheck, Clock, Info, Lightbulb, ThumbsDown } from "lucide-react";
import { PersonaBox, RelevanceTags, SaveButton, Section, SourceLine } from "@/components/brief/StoryParts";
import StoryVisual from "@/components/shared/StoryVisual";
import { Button } from "@/components/shared/ui";
import { copy, getStory, stories } from "@/lib/content";
import { deepDiveMinutes } from "@/lib/reading-time";
import { useApp } from "@/lib/state";

function CaughtUp() {
  const { state, openScreen, closeReader } = useApp();
  return (
    <div className="mx-auto flex max-w-[560px] flex-col items-center px-6 py-24 text-center">
      <div className="flex h-14 w-14 animate-pop items-center justify-center rounded-full bg-navy text-white">
        <CircleCheck size={26} aria-hidden />
      </div>
      <h1 className="mt-6 font-serif text-[30px] font-semibold text-navy">You’re caught up.</h1>
      <p className="mt-2 text-[15px] text-muted">
        {copy("no more stories in queue", "We’ll have more important stories when there’s something worth your attention.").replace(/^You’re caught up\.\s*/, "")}
      </p>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        {state.stage === "meeting" && (
          <Button onClick={closeReader}>
            <ArrowLeft size={16} aria-hidden /> Return to meeting
          </Button>
        )}
        <Button variant="secondary" onClick={() => openScreen("saved")}>
          View saved stories
        </Button>
      </div>
    </div>
  );
}

export default function BriefView() {
  const { state, queue, openStory, setSimplified, markReadAndNext, notInterested, toast } = useApp();
  const story = getStory(state.reader.storyId) ?? (state.reader.storyId ? undefined : queue[0]);

  if (!story) {
    if (state.reader.storyId) {
      return (
        <p className="px-8 py-24 text-center text-muted">
          {copy("story unavailable state", "This story isn’t available right now. Try another story from your queue.")}
        </p>
      );
    }
    return <CaughtUp />;
  }

  const simplified = state.reader.simplified && story.briefSimplified.length > 0;
  const sections = simplified ? story.briefSimplified : story.briefStandard;
  const [lead, ...rest] = sections;
  const position = stories.findIndex((s) => s.id === story.id) + 1;
  const isRead = state.readIds.includes(story.id);
  const flagged = state.notInterestedIds.includes(story.id);
  const remaining = stories.filter((s) => !state.readIds.includes(s.id)).length;

  // Place the personal box right before "What to watch next" (or at the end).
  const watchIdx = rest.findIndex((s) => /watch|next/i.test(s.heading));
  const before = watchIdx >= 0 ? rest.slice(0, watchIdx) : rest;
  const after = watchIdx >= 0 ? rest.slice(watchIdx) : [];

  return (
    <article className="mx-auto max-w-[880px] px-5 pt-8 pb-32 sm:px-10 sm:pt-10">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[13px] text-muted">
          <span className="font-semibold text-teams">{story.category}</span>
          <span className="inline-flex items-center gap-1">
            <Clock size={13} aria-hidden /> 2 min read
          </span>
          <RelevanceTags story={story} />
          {isRead && (
            <span className="inline-flex items-center gap-1 text-[#2f7a4f]">
              <Check size={13} aria-hidden /> Read
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={() => openStory(story.id, "deep")}>
            <BookOpen size={16} aria-hidden /> Deep dive · {deepDiveMinutes(story)} min
          </Button>
          <SaveButton story={story} />
        </div>
      </header>

      <h1 className="mt-5 font-serif text-[30px] leading-[1.18] font-semibold text-navy sm:text-[36px]">{story.headline}</h1>

      {simplified && (
        <div className="mt-5 flex items-start gap-3 rounded-lg border border-line bg-white px-4 py-3 text-[13.5px] text-[#2c3a50]" role="status">
          <Lightbulb size={17} className="mt-0.5 shrink-0 text-orange" aria-hidden />
          <p className="flex-1">
            {copy("too technical explanation", "Here’s the same story in simpler language, with the important facts and implications preserved.")}
          </p>
          <button type="button" onClick={() => setSimplified(false)} className="shrink-0 font-semibold text-navy underline-offset-2 hover:underline">
            Show standard version
          </button>
        </div>
      )}

      <div className="mt-7 space-y-8">
        {lead && (
          <div className="grid gap-6 md:grid-cols-[minmax(0,1fr)_220px]">
            <Section section={lead} />
            <StoryVisual story={story} className="h-[150px] rounded-xl md:h-[160px]" />
          </div>
        )}
        {before.map((s) => (
          <Section key={s.heading} section={s} />
        ))}
        <PersonaBox story={story} />
        {after.map((s) => (
          <Section key={s.heading} section={s} />
        ))}
        <div className="border-t border-line pt-5">
          <SourceLine story={story} />
        </div>
      </div>

      {/* Action bar */}
      <div className="sticky bottom-4 z-10 mt-10">
        <div className="flex flex-wrap items-center gap-2 rounded-xl border border-line bg-white/95 p-2.5 shadow-[0_12px_40px_-16px_rgba(23,36,58,0.35)] backdrop-blur">
          <Button size="lg" onClick={() => markReadAndNext(story.id, "reader")}>
            <Check size={17} aria-hidden /> Mark as read &amp; next <ArrowRight size={16} aria-hidden />
          </Button>
          <Button
            variant="ghost"
            disabled={flagged}
            onClick={() => {
              notInterested(story.id);
              toast(copy("not interested confirmation", "Got it. We’ll use this feedback to improve the stories we show you."));
            }}
          >
            <ThumbsDown size={15} aria-hidden /> {flagged ? "Feedback noted" : "Not interested"}
          </Button>
          {story.briefSimplified.length > 0 && (
            <Button variant="ghost" onClick={() => setSimplified(!simplified)} aria-pressed={simplified}>
              <Info size={15} aria-hidden /> {simplified ? "Standard version" : copy("too technical label", "Too technical")}
            </Button>
          )}
          <span className="ml-auto hidden pr-2 text-[12px] text-muted sm:inline">
            Story {position} of {stories.length} · {remaining} unread
          </span>
        </div>
      </div>
    </article>
  );
}
