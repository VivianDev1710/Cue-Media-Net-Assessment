/**
 * Original, understated two-note chime generated with the Web Audio API.
 * No asset, no external API. If the browser blocks audio (autoplay policy), it fails silently.
 */
let ctx: AudioContext | null = null;

export async function playChime(): Promise<void> {
  if (typeof window === "undefined") return;
  try {
    const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    ctx = ctx ?? new AC();
    if (ctx.state === "suspended") await ctx.resume();
    if (ctx.state !== "running") return;
    const now = ctx.currentTime;
    const notes: [number, number][] = [
      [659.25, 0], // E5
      [987.77, 0.14], // B5
    ];
    for (const [freq, offset] of notes) {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0, now + offset);
      gain.gain.linearRampToValueAtTime(0.08, now + offset + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + offset + 0.6);
      osc.connect(gain).connect(ctx.destination);
      osc.start(now + offset);
      osc.stop(now + offset + 0.65);
    }
  } catch {
    /* silent fallback */
  }
}

/** Call from a user gesture (e.g. Finish Setup) so a later chime is allowed to play. */
export function primeAudio() {
  if (typeof window === "undefined") return;
  try {
    const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    ctx = ctx ?? new AC();
    if (ctx.state === "suspended") void ctx.resume();
  } catch {
    /* ignore */
  }
}
