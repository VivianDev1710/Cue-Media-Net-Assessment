"use client";

import { Check } from "lucide-react";
import type { ButtonHTMLAttributes, ReactNode } from "react";
import { LOGO_SRC, LOGO_WHITE_SRC } from "@/lib/logo";

/** Cue wordmark. Size it with a text-size class: the mark is 0.8em tall. */
export function Logo({ className = "", dark = false }: { className?: string; dark?: boolean }) {
  return (
    <span className={`inline-flex shrink-0 items-center leading-none ${className}`}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={dark ? LOGO_WHITE_SRC : LOGO_SRC} alt="cue." draggable={false} style={{ height: "0.8em", width: "auto" }} />
    </span>
  );
}

type Variant = "primary" | "secondary" | "ghost" | "danger";
const VARIANTS: Record<Variant, string> = {
  primary: "bg-navy text-white hover:bg-navy-2 disabled:bg-navy/30 disabled:text-white/80",
  secondary: "bg-white text-navy border border-line hover:border-navy/30 hover:bg-ivory disabled:opacity-50",
  ghost: "text-muted hover:text-navy hover:bg-navy/5 disabled:opacity-50",
  danger: "bg-[#b42318] text-white hover:bg-[#912018]",
};

export function Button({
  variant = "primary",
  size = "md",
  className = "",
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; size?: "sm" | "md" | "lg"; ref?: React.Ref<HTMLButtonElement> }) {
  const sizes = { sm: "h-8 px-3 text-[13px] gap-1.5", md: "h-10 px-4 text-sm gap-2", lg: "h-12 px-6 text-[15px] gap-2" };
  return (
    <button
      type="button"
      className={`inline-flex items-center justify-center rounded-lg font-semibold transition-colors disabled:cursor-not-allowed ${sizes[size]} ${VARIANTS[variant]} ${className}`}
      {...rest}
    >
      {children}
    </button>
  );
}

export function Chip({
  selected,
  disabled,
  onClick,
  children,
}: {
  selected: boolean;
  disabled?: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={selected}
      disabled={disabled && !selected}
      onClick={onClick}
      className={`inline-flex items-center gap-1.5 rounded-md border px-3 py-1.5 text-[13px] font-medium transition-colors ${
        selected
          ? "border-navy bg-navy text-white"
          : "border-line bg-white text-navy hover:border-navy/40 disabled:cursor-not-allowed disabled:opacity-40"
      }`}
    >
      {selected && <Check size={13} strokeWidth={2.5} aria-hidden />}
      {children}
    </button>
  );
}

export function Toggle({
  checked,
  onChange,
  label,
  id,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
  id?: string;
}) {
  return (
    <button
      id={id}
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${checked ? "bg-navy" : "bg-[#cfd5de]"}`}
    >
      <span
        className={`absolute top-0.5 left-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${checked ? "translate-x-5" : ""}`}
      />
    </button>
  );
}

export function Avatar({
  text,
  size = 64,
  tone = "rose",
  className = "",
}: {
  text: string;
  size?: number;
  tone?: "rose" | "lilac" | "navy";
  className?: string;
}) {
  const tones = {
    rose: "bg-[#fcdcd6] text-[#7f2f25]",
    lilac: "bg-[#dcdcf4] text-[#3d3f86]",
    navy: "bg-navy text-white",
  };
  return (
    <div
      className={`flex shrink-0 select-none items-center justify-center rounded-full font-semibold ${tones[tone]} ${className}`}
      style={{ width: size, height: size, fontSize: size * 0.36 }}
      aria-hidden
    >
      {text}
    </div>
  );
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return <p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-muted">{children}</p>;
}
