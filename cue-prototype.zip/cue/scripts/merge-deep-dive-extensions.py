"""Editorial merge: inserts the extended deep-dive sections from scripts/deep-dive-extensions/CUE-xxx.md
into data/cue_news_today.md, renames "N-minute deep dive" headings to "10-minute deep dive", and tags
every added section with a Cue-analysis marker right under its heading (the app shows it as a label).
Idempotent: sections already present are left alone."""
import pathlib, re

root = pathlib.Path(__file__).resolve().parent.parent
md_path = root / "data" / "cue_news_today.md"
md = md_path.read_text()
MARK = "<!-- Cue analysis: added to extend the deep dive. Explanatory, built on the facts above; no new reported claims. -->"
md = md.replace(MARK + "\n\n", "").replace(MARK + "\n", "").replace(MARK, "")

for ext in sorted((root / "scripts" / "deep-dive-extensions").glob("CUE-*.md")):
    sid = ext.stem
    start = md.index(f"## {sid} — ")
    end = md.find("\n## ", start + 5)
    story = re.sub(r"### \d+-minute deep dive", "### 10-minute deep dive", md[start:end])
    raw = re.split(r"^@after (.+)$", ext.read_text(), flags=re.M)[1:]
    headings = []
    for anchor, content in zip(raw[0::2], raw[1::2]):
        content = content.strip()
        headings += re.findall(r"^### .+$", content, flags=re.M)
        if content.splitlines()[0] in story:
            continue
        dd = story.index("### 10-minute deep dive")
        a = story.index(f"### {anchor.strip()}", dd)
        assert a < story.index("### Why it matters to you"), (sid, anchor)
        nxt = story.index("\n### ", a + 4)
        story = story[: nxt + 1] + content + "\n\n" + story[nxt + 1 :]
    for h in headings:
        story = story.replace(h + "\n", h + "\n\n" + MARK + "\n", 1)
    md = md[:start] + story + md[end:]

md_path.write_text(md)
print("merged")
