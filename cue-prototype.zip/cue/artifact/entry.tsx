import { createRoot } from "react-dom/client";
import CueRoot from "@/components/CueRoot";
createRoot(document.getElementById("root")!).render(<CueRoot />);
