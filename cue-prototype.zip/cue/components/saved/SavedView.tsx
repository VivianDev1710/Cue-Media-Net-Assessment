"use client";

import { ArrowRight, Bookmark, BookOpen, Check, Trash2 } from "lucide-react";
import StoryVisual from "@/components/shared/StoryVisual";
import { getStory } from "@/lib/content";
import { useApp } from "@/lib/state";

export default function SavedView() {
  const { state, openStory, toggleSave, toast } = useApp();
  const saved = state.savedIds.map((id) => getStory(id)).filter((s): s is NonNullable<typeof s> => Boolean(s));

  return (
    <section className="mx-auto max-w-[880px] px-5 pt-10 pb-24 sm:px-10">
      <h1 className="font-serif text-[32px] font-semibold text-navy">Saved</h1>
      <p className="mt-1 text-[14px] text-muted">Stories you bookmarked, kept on this device.</p>

      {saved.length === 0 ? (
        <div className="mt-12 flex flex-col items-center rounded-2xl border border-dashed border-line bg-white px-6 py-16 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-ivory text-muted">
            <Bookmark size={22} aria-hidden />
          </div>
          <p className="mt-4 text-[17px] font-semibold text-navy">Your saved stories will appear here.</p>
          <p className="mt-1 text-[14px] text-muted">Bookmark stories you want to revisit.</p>
        </div>
      ) : (
        <ul className="mt-8 divide-y divide-line overflow-hidden rounded-2xl border border-line bg-white">
          {saved.map((s) => (
            <li key={s.id} className="flex gap-4 p-5">
              <StoryVisual story={s} className="hidden h-[76px] w-[110px] shrink-0 rounded-lg sm:block" iconSize={26} />
              <div className="min-w-0 flex-1">
                <p className="flex flex-wrap items-center gap-2 text-[12px] text-muted">
                  <span className="font-semibold text-teams">{s.category}</span>
                  {state.readIds.includes(s.id) && (
                    <span className="inline-flex items-center gap-1 text-[#2f7a4f]">
                      <Check size={12} aria-hidden /> Read
                    </span>
                  )}
                </p>
                <button
                  type="button"
                  onClick={() => openStory(s.id, "brief")}
                  className="mt-1 text-left text-[16.5px] leading-snug font-semibold text-navy hover:text-teams"
                >
                  {s.headline}
                </button>
                <p className="mt-1 line-clamp-2 text-[13.5px] text-[#3d4a5f]">{s.cue20}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => openStory(s.id, "brief")}
                    className="inline-flex h-8 items-center gap-1.5 rounded-md bg-navy px-3 text-[12.5px] font-semibold text-white hover:bg-navy-2"
                  >
                    Open brief <ArrowRight size={13} aria-hidden />
                  </button>
                  <button
                    type="button"
                    onClick={() => openStory(s.id, "deep")}
                    className="inline-flex h-8 items-center gap-1.5 rounded-md border border-line px-3 text-[12.5px] font-semibold text-navy hover:bg-ivory"
                  >
                    <BookOpen size={13} aria-hidden /> Deep dive
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      toggleSave(s.id);
                      toast("Removed from Saved");
                    }}
                    className="inline-flex h-8 items-center gap-1.5 rounded-md px-3 text-[12.5px] font-medium text-muted hover:bg-navy/5 hover:text-navy"
                  >
                    <Trash2 size={13} aria-hidden /> Remove
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
