import { FUNCTIONS, functionById } from "@/lib/taxonomy";
import type { PersonaImplication, PersonaKey, Story } from "@/types/story";

export interface ResolvedPersona {
  implication: PersonaImplication | null;
  /** Shown when the user's function has no exact persona in the library. */
  note: string | null;
  /** e.g. "Finance & Investment · Director" */
  audience: string;
}

export function personaKeyForFunction(functionId: string): { key: PersonaKey; exact: boolean; label: string } {
  const f = functionById(functionId) ?? FUNCTIONS[0];
  return { key: f.persona, exact: f.exact, label: f.label };
}

export function resolvePersona(story: Story, functionId: string, seniority = ""): ResolvedPersona {
  const { key, exact, label } = personaKeyForFunction(functionId);
  const audience = [functionById(functionId)?.label ?? label, seniority].filter(Boolean).join(" · ");
  const list = story.personaImplications ?? [];
  const match = list.find((p) => p.key === key);
  if (match) {
    return { implication: match, audience, note: exact ? null : `Closest available perspective: ${match.label}` };
  }
  const fallback = list.find((p) => p.key === "CEO") ?? list[0] ?? null;
  return { implication: fallback, audience, note: fallback ? `Closest available perspective: ${fallback.label}` : null };
}

export function otherPersonas(story: Story, current: PersonaImplication | null): PersonaImplication[] {
  return (story.personaImplications ?? []).filter((p) => p.key !== current?.key);
}
