"use client";

import { Hand, MicOff, X } from "lucide-react";
import { useEffect, useState } from "react";
import CueCard from "@/components/news/CueCard";
import MeetingToolbar from "@/components/meeting/MeetingToolbar";
import { Avatar } from "@/components/shared/ui";
import { MEETING } from "@/lib/constants";
import { formatElapsed, initials, useApp, useNow } from "@/lib/state";

const REACTIONS = ["👍", "❤️", "👏", "😄"];

function NameLabel({ name, raised }: { name: string; raised?: boolean }) {
  return (
    <div className="absolute bottom-2.5 left-2.5 flex items-center gap-1.5 rounded bg-black/55 px-2 py-1 text-[12px] text-white">
      {raised && <Hand size={13} className="text-[#f2c94c]" aria-label="Hand raised" />}
      <MicOff size={12} className="text-white/80" aria-label="Microphone off" />
      {name}
    </div>
  );
}

export default function MeetingScreen() {
  const { state, leaveMeeting, toggleRaise, toast } = useApp();
  const now = useNow();
  const [panel, setPanel] = useState<"chat" | "people" | null>(null);
  const [reactOpen, setReactOpen] = useState(false);
  const [floating, setFloating] = useState<{ id: number; emoji: string }[]>([]);

  const { meeting, profile } = state;
  // The cue card appears MEETING.cardDelayMs (2s) after joining — measured from joinedAt, so it is repeatable on every join.
  const [cardReady, setCardReady] = useState(() => Boolean(meeting.joinedAt && Date.now() - meeting.joinedAt >= MEETING.cardDelayMs));
  const [justRevealed, setJustRevealed] = useState(false);
  useEffect(() => {
    if (cardReady || !meeting.joinedAt) return;
    let t2: ReturnType<typeof setTimeout> | undefined;
    const t = setTimeout(() => {
      setCardReady(true);
      setJustRevealed(true);
      t2 = setTimeout(() => setJustRevealed(false), 600);
    }, Math.max(0, meeting.joinedAt + MEETING.cardDelayMs - Date.now()));
    return () => {
      clearTimeout(t);
      if (t2) clearTimeout(t2);
    };
  }, [cardReady, meeting.joinedAt]);
  const elapsed = formatElapsed(now - (meeting.joinedAt ?? now));
  const joined = Boolean(meeting.participantJoinedAt);
  const me = initials(profile.name);
  const myName = profile.name.trim() || "You";
  const other = initials(MEETING.participantName);

  const react = (emoji: string) => {
    const id = Date.now();
    setFloating((f) => [...f, { id, emoji }]);
    setReactOpen(false);
    setTimeout(() => setFloating((f) => f.filter((x) => x.id !== id)), 1700);
  };

  const people = [
    { name: `${myName} (You)`, init: me, tone: "rose" as const, note: "Organiser" },
    ...(joined ? [{ name: MEETING.participantName, init: other, tone: "lilac" as const, note: "Attendee" }] : []),
  ];

  return (
    <main className="flex h-screen flex-col overflow-hidden bg-meet text-white" aria-label={`${MEETING.title} meeting`}>
      <MeetingToolbar
        elapsed={elapsed}
        panel={panel}
        raised={meeting.raised}
        handlers={{
          onChat: () => setPanel((p) => (p === "chat" ? null : "chat")),
          onPeople: () => setPanel((p) => (p === "people" ? null : "people")),
          onRaise: toggleRaise,
          onReact: () => setReactOpen((v) => !v),
          onUnavailable: (f) => toast(`${f}: not available in this prototype.`, "dark"),
          onCamera: () => toast("Your camera stays off. Cue never needs it.", "dark"),
          onMic: () => toast("You’re muted. Nobody has started speaking yet.", "dark"),
          onLeave: leaveMeeting,
        }}
        reactPopover={
          reactOpen ? (
            <div className="absolute top-[64px] left-1/2 z-30 flex -translate-x-1/2 animate-fade-in gap-1 rounded-lg bg-[#2d2d2d] p-1.5 shadow-xl ring-1 ring-white/10">
              {REACTIONS.map((r) => (
                <button key={r} type="button" onClick={() => react(r)} className="rounded-md px-2 py-1 text-xl hover:bg-white/10" aria-label={`React ${r}`}>
                  {r}
                </button>
              ))}
            </div>
          ) : null
        }
      />

      <div className="flex min-h-0 flex-1">
        {/* Stage */}
        <div className="relative flex min-w-0 flex-1 flex-col">
          <div className="relative flex min-h-0 flex-1 items-center justify-center p-4 sm:p-6">
            {!joined ? (
              <div className="flex animate-fade-in flex-col items-center text-center">
                <div className="relative">
                  <Avatar text={me} size={132} className="sm:h-[152px] sm:w-[152px]" />
                  {meeting.raised && (
                    <span className="absolute -top-1 -right-1 rounded-full bg-[#2d2d2d] p-2 ring-1 ring-white/20">
                      <Hand size={18} className="text-[#f2c94c]" aria-label="Hand raised" />
                    </span>
                  )}
                </div>
                <p className="mt-7 text-[20px] font-semibold sm:text-[24px]">Waiting for others to join…</p>
              </div>
            ) : (
              <div className="relative flex h-full max-h-[520px] w-full max-w-[920px] animate-fade-in items-center justify-center rounded-lg bg-meet-tile">
                <Avatar text={other} size={128} tone="lilac" />
                <NameLabel name={MEETING.participantName} />
              </div>
            )}

            {joined && (
              <div className="absolute right-4 bottom-4 hidden h-[118px] w-[200px] animate-pop items-center justify-center rounded-lg bg-[#2b2b2b] ring-1 ring-white/10 sm:flex">
                <Avatar text={me} size={52} />
                <NameLabel name="You" raised={meeting.raised} />
              </div>
            )}

            {floating.map((f) => (
              <span key={f.id} className="pointer-events-none absolute bottom-24 left-1/2 animate-float-up text-4xl" aria-hidden>
                {f.emoji}
              </span>
            ))}
          </div>

          {/* Cue overlay zone */}
          <div className="flex min-h-[248px] shrink-0 flex-col justify-end px-3 pb-4 sm:px-6 sm:pb-6">
            {joined && (
              <p className="mx-auto mb-2 flex w-fit animate-fade-in items-center gap-2 rounded-full bg-black/40 px-3 py-1 text-[12.5px] text-white/80" role="status">
                <span className="h-1.5 w-1.5 rounded-full bg-white/50" aria-hidden />
                No one has started speaking yet.
              </p>
            )}
            {cardReady && <CueCard attention={justRevealed} />}
          </div>
        </div>

        {/* Side panel */}
        {panel && (
          <aside className="w-[300px] shrink-0 animate-fade-in border-l border-white/10 bg-[#292929] max-md:absolute max-md:top-[72px] max-md:right-0 max-md:bottom-0 max-md:z-20">
            <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
              <h2 className="text-[15px] font-semibold">{panel === "people" ? "Participants" : "Meeting chat"}</h2>
              <button type="button" onClick={() => setPanel(null)} className="rounded p-1 text-white/70 hover:bg-white/10" aria-label="Close panel">
                <X size={16} />
              </button>
            </div>
            {panel === "people" ? (
              <ul className="p-2">
                <li className="px-2 pt-1 pb-2 text-[12px] text-white/50">In this meeting ({people.length})</li>
                {people.map((p) => (
                  <li key={p.name} className="flex items-center gap-3 rounded-md px-2 py-2 hover:bg-white/5">
                    <Avatar text={p.init} size={32} tone={p.tone} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13.5px]">{p.name}</p>
                      <p className="text-[11.5px] text-white/50">{p.note}</p>
                    </div>
                    <MicOff size={14} className="text-white/50" aria-label="Muted" />
                  </li>
                ))}
              </ul>
            ) : (
              <div className="p-6 text-center text-[13px] text-white/60">
                <p className="font-semibold text-white/80">No messages yet</p>
                <p className="mt-1">Chat is simulated in this prototype.</p>
              </div>
            )}
          </aside>
        )}
      </div>
    </main>
  );
}
