"use client";

import { RotateCcw } from "lucide-react";
import { useEffect, useRef } from "react";
import { Button } from "@/components/shared/ui";
import { useApp } from "@/lib/state";

/** Confirmation before restarting the whole prototype journey (used by the sidebar and setup-complete screen). */
export default function ResetDialog({ onClose }: { onClose: () => void }) {
  const { reset } = useApp();
  const cancelRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    cancelRef.current?.focus();
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-[75] flex items-center justify-center bg-navy/40 p-4 backdrop-blur-[2px]"
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <div role="alertdialog" aria-modal="true" aria-labelledby="reset-title" aria-describedby="reset-desc" className="w-full max-w-[420px] animate-rise rounded-2xl bg-white p-6 shadow-2xl">
        <div className="flex h-11 w-11 items-center justify-center rounded-full bg-orange-soft text-[#b5630f]">
          <RotateCcw size={20} aria-hidden />
        </div>
        <h2 id="reset-title" className="mt-4 font-serif text-[22px] font-semibold text-navy">
          Start the journey again?
        </h2>
        <p id="reset-desc" className="mt-1.5 text-[14px] leading-relaxed text-muted">
          This resets the whole prototype: your setup choices, the meeting, its timers and participants, and read, saved and dismissed stories. You’ll return to step 1 of setup.
        </p>
        <div className="mt-6 flex justify-end gap-2">
          <Button ref={cancelRef} variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant="danger"
            onClick={() => {
              onClose();
              reset();
            }}
          >
            Reset prototype
          </Button>
        </div>
      </div>
    </div>
  );
}
