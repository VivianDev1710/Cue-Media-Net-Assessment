// Story model generated from data/cue_news_today.md by scripts/build-content.ts

export type PersonaKey = "CEO" | "CFO" | "COO" | "CTO" | "CMO" | "CHRO";

export interface BriefSection {
  heading: string;
  body: string;
  /** true for sections Cue added to extend the reporting (marked in the Markdown) */
  analysis?: boolean;
}

export interface PersonaImplication {
  key: PersonaKey;
  label: string; // e.g. "COO / Supply Chain / Operations"
  body: string;
}

export interface Story {
  id: string;
  rank: number;
  headline: string;
  category: string;
  source: string;
  sourceUrl: string;
  corroboratingSource?: string;
  corroboratingUrl?: string;
  publishedAt: string;
  geography?: string;
  importance: number;
  rankingRationale?: string;
  cue20: string;
  /** 2–3 line takeaway of the whole article, shown on the in-meeting cue card */
  cardSummary?: string;
  briefStandard: BriefSection[];
  briefSimplified: BriefSection[];
  deepDive: BriefSection[];
  personaImplications: PersonaImplication[];
  image?: string;
  tags: string[];
}

export interface BackupStory {
  id: string;
  rank?: number;
  headline: string;
  category: string;
  summary: string;
  source: string;
  sourceUrl: string;
}

export interface ContentLibrary {
  meta: {
    date: string;
    generatedAt: string;
    editorialStatus?: string;
    builtAt: string;
  };
  stories: Story[];
  backups: BackupStory[];
  interactionCopy: Record<string, string>;
  warnings: string[];
}
