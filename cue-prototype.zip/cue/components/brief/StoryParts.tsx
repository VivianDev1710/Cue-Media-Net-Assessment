"use client";

import { Bookmark, BookmarkCheck, ExternalLink, Sparkles } from "lucide-react";
import type { ReactNode } from "react";
import { storyTopics } from "@/lib/taxonomy";
import { resolvePersona } from "@/lib/persona";
import { useApp } from "@/lib/state";
import type { BriefSection, Story } from "@/types/story";

export function Paragraphs({ text, className = "" }: { text: string; className?: string }) {
  return (
    <div className={`prose-cue ${className}`}>
      {text.split("\n\n").map((p, i) =>
        p.startsWith("- ") ? (
          <ul key={i} className="space-y-2 pl-1">
            {p.split("\n").map((li, j) => (
              <li key={j} className="flex gap-3">
                <span className="mt-[0.7em] h-1.5 w-1.5 shrink-0 rounded-full bg-orange" aria-hidden />
                <span>{li.replace(/^- /, "")}</span>
              </li>
            ))}
          </ul>
        ) : p.endsWith("?") && p.length < 140 ? (
          <p key={i} className="font-semibold text-navy">
            {p}
          </p>
        ) : (
          <p key={i}>{p}</p>
        ),
      )}
    </div>
  );
}

export function Section({ section, id, children }: { section: BriefSection; id?: string; children?: ReactNode }) {
  return (
    <section id={id} className="scroll-mt-6">
      <h2 className="flex flex-wrap items-center gap-2 text-[13px] font-semibold tracking-[0.08em] text-navy uppercase">
        {section.heading}
        {section.analysis && (
          <span className="rounded bg-[#eceaf6] px-1.5 py-0.5 text-[10.5px] font-semibold tracking-normal text-teams normal-case" title="Explains and extends the reporting; no new reported claims">
            Cue analysis
          </span>
        )}
      </h2>
      <Paragraphs text={section.body} className="mt-2 text-[15.5px] leading-[1.7] text-[#2c3a50]" />
      {children}
    </section>
  );
}

export function SaveButton({ story, withLabel = false }: { story: Story; withLabel?: boolean }) {
  const { state, toggleSave, toast } = useApp();
  const saved = state.savedIds.includes(story.id);
  return (
    <button
      type="button"
      onClick={() => {
        toggleSave(story.id);
        toast(saved ? "Removed from Saved" : "Saved for later");
      }}
      aria-pressed={saved}
      aria-label={saved ? "Remove from saved" : "Save story"}
      title={saved ? "Saved" : "Save"}
      className="inline-flex h-10 items-center gap-2 rounded-lg border border-line bg-white px-3 text-[13.5px] font-semibold text-navy hover:bg-ivory"
    >
      {saved ? <BookmarkCheck size={18} className="text-orange" aria-hidden /> : <Bookmark size={18} aria-hidden />}
      {withLabel && <span>{saved ? "Saved" : "Save"}</span>}
    </button>
  );
}

export function RelevanceTags({ story }: { story: Story }) {
  const { state } = useApp();
  const mine = new Set([...state.profile.topics, ...state.profile.interests]);
  const matched = storyTopics(`${story.headline} ${story.category}`).filter((t) => mine.has(t));
  if (!matched.length) return null;
  return (
    <span className="inline-flex items-center gap-1 text-[12.5px] text-muted">
      <Sparkles size={12} className="text-orange" aria-hidden /> You follow {matched.slice(0, 2).join(" & ")}
    </span>
  );
}

export function PersonaBox({ story, detailed = false }: { story: Story; detailed?: boolean }) {
  const { state } = useApp();
  const { implication, note, audience } = resolvePersona(story, state.profile.function, state.profile.seniority);
  return (
    <aside className="rounded-xl border border-[#f4d6b5] bg-orange-soft p-5 sm:p-6" aria-labelledby={`wim-${story.id}`}>
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 id={`wim-${story.id}`} className={`font-serif font-semibold text-navy ${detailed ? "text-[24px]" : "text-[19px]"}`}>
          <span className="mr-1.5 text-orange" aria-hidden>
            ★
          </span>
          Why it matters to you
        </h2>
        {implication && <span className="text-[12px] font-semibold text-[#9a5410]">For you in {audience}</span>}
      </div>
      {implication ? (
        <Paragraphs text={implication.body} className={`mt-2.5 leading-[1.7] text-[#2c3a50] ${detailed ? "text-[16.5px]" : "text-[15px]"}`} />
      ) : (
        <p className="mt-2 text-[14px] text-muted">A role-specific view isn’t available for this story yet.</p>
      )}
      {note && <p className="mt-3 text-[12px] text-[#9a5410]">{note}</p>}
    </aside>
  );
}

export function SourceLine({ story }: { story: Story }) {
  return (
    <p className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[12.5px] text-muted">
      <span>Source:</span>
      {story.sourceUrl ? (
        <a href={story.sourceUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 font-semibold text-navy underline-offset-2 hover:underline">
          {story.source} <ExternalLink size={12} aria-hidden />
        </a>
      ) : (
        <span>{story.source || "Unknown"}</span>
      )}
      {story.corroboratingSource && story.corroboratingUrl && story.corroboratingUrl !== story.sourceUrl && (
        <a href={story.corroboratingUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 hover:text-navy hover:underline">
          Also: {story.corroboratingSource} <ExternalLink size={12} aria-hidden />
        </a>
      )}
      {story.publishedAt && <span>· {story.publishedAt}</span>}
    </p>
  );
}
