import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "cue. — News that fits your workday",
  description: "Cue is a contextual news prototype for busy executives.",
};

export const viewport: Viewport = { themeColor: "#17243A" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
