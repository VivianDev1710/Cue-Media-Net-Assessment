"use client";

import { Compass, Heart, Plus, RotateCcw, Sparkles, Target, X } from "lucide-react";
import { useState } from "react";
import Combobox from "@/components/setup/Combobox";
import ExploreDialog from "@/components/setup/ExploreDialog";
import { Chip } from "@/components/shared/ui";
import type { Profile } from "@/lib/state";
import {
  countItems,
  FUNCTIONS,
  functionById,
  INDUSTRIES,
  INTEREST_CATALOG,
  INTEREST_EXAMPLES,
  MAX_INTERESTS,
  defaultSelection,
  MAX_TOPICS,
  SENIORITY,
  suggestTheme,
  suggestTopics,
  THEMES,
  TOPIC_CATALOG,
} from "@/lib/taxonomy";

function toggleIn(list: string[], v: string, max: number): string[] {
  if (list.includes(v)) return list.filter((x) => x !== v);
  return list.length >= max ? list : [...list, v];
}

export function missingProfileFields(p: Profile): string[] {
  return [
    !p.function && "function",
    !p.seniority && "seniority",
    !p.industry && "industry",
    !p.topics.length && "at least one thing that matters to your work",
  ].filter((x): x is string => Boolean(x));
}

export function profileComplete(p: Profile): boolean {
  return missingProfileFields(p).length === 0;
}

/** Removable selected chip. */
function SelectedChip({ label, onRemove, suggested }: { label: string; onRemove: () => void; suggested?: boolean }) {
  return (
    <span className="inline-flex animate-pop items-center gap-1 rounded-md border border-navy bg-navy py-1 pr-1 pl-3 text-[13px] font-medium text-white">
      {suggested && <Sparkles size={12} className="text-orange" aria-hidden />}
      {label}
      <button
        type="button"
        onClick={onRemove}
        aria-label={`Remove ${label}`}
        className="ml-0.5 rounded p-0.5 text-white/70 hover:bg-white/15 hover:text-white"
      >
        <X size={13} />
      </button>
    </span>
  );
}

function AddChip({ label, onAdd, disabled }: { label: string; onAdd: () => void; disabled: boolean }) {
  return (
    <button
      type="button"
      onClick={onAdd}
      disabled={disabled}
      aria-label={`Add ${label}`}
      className="inline-flex items-center gap-1 rounded-md border border-dashed border-navy/30 bg-white px-3 py-1 text-[13px] font-medium text-navy hover:border-navy hover:bg-ivory disabled:cursor-not-allowed disabled:opacity-40"
    >
      <Plus size={13} aria-hidden className="text-muted" />
      {label}
    </button>
  );
}

function ExploreButton({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-[13px] font-semibold text-teams hover:bg-[#eceaf6]"
    >
      <Compass size={14} aria-hidden /> {label}
    </button>
  );
}

export default function ProfileFields({
  profile,
  onChange,
  compact = false,
}: {
  profile: Profile;
  onChange: (patch: Partial<Profile>) => void;
  compact?: boolean;
}) {
  const [explore, setExplore] = useState<"topics" | "interests" | null>(null);
  const roleTopics = suggestTopics(profile.function, profile.industry);
  const roleTheme = suggestTheme(profile.function);
  const roleReady = roleTopics.length > 0;
  const suggestedSet = new Set([...(roleTheme ? [roleTheme] : []), ...roleTopics]);
  const fn = functionById(profile.function);

  /** Function/industry changes refresh the pre-selection until the user edits it by hand. */
  const update = (patch: Partial<Profile>) => {
    const next = { ...profile, ...patch };
    if (("function" in patch || "industry" in patch) && !next.topicsCustomised) {
      patch = { ...patch, topics: defaultSelection(next.function, next.industry) };
    }
    onChange(patch);
  };
  const toggleTopic = (t: string) => onChange({ topics: toggleIn(profile.topics, t, MAX_TOPICS), topicsCustomised: true });
  const toggleInterest = (t: string) => onChange({ interests: toggleIn(profile.interests, t, MAX_INTERESTS) });

  const full = profile.topics.length >= MAX_TOPICS;
  // Each item appears once: selected items show only in the selection; role topics never repeat in the theme row.
  const moreForRole = roleTopics.filter((t) => !profile.topics.includes(t));
  const moreThemes = THEMES.filter((t) => !profile.topics.includes(t));
  const extraInterests = profile.interests.filter((i) => !INTEREST_EXAMPLES.includes(i));

  return (
    <>
      <div className="space-y-8">
        {/* Who you are */}
        <div className={`grid gap-5 ${compact ? "" : "md:grid-cols-2"}`}>
          <div>
              <label htmlFor="name" className="text-[13px] font-semibold text-navy">
                Your name <span className="font-normal text-muted">(optional)</span>
              </label>
              <input
                id="name"
                className="mt-1.5 h-11 w-full rounded-lg border border-line bg-white px-3 text-[14px] text-navy placeholder:text-muted/80 hover:border-navy/40 focus:border-navy focus:outline-none"
                value={profile.name}
                placeholder="e.g. Vivian Joseph"
                autoComplete="name"
                onChange={(e) => onChange({ name: e.target.value })}
              />
          </div>
          <Combobox
            id="function"
            label="Function"
            placeholder="Select your function"
            options={FUNCTIONS}
            value={profile.function}
            onChange={(v) => update({ function: v })}
          />
          <Combobox
            id="seniority"
            label="Seniority"
            placeholder="Select seniority"
            options={SENIORITY}
            value={profile.seniority}
            onChange={(v) => update({ seniority: v })}
          />
          <Combobox
            id="industry"
            label="Industry"
            placeholder="Search industries"
            options={INDUSTRIES}
            value={profile.industry}
            onChange={(v) => update({ industry: v })}
          />
        </div>

        <div className={`grid gap-4 ${compact ? "" : "lg:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)] lg:items-start"}`}>
          {/* Unified: themes + role topics, one limit */}
          <section className="rounded-xl border border-line bg-ivory/60 p-4 sm:p-5" aria-labelledby="topics-h">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 id="topics-h" className="flex items-center gap-2 text-[14px] font-semibold text-navy">
                  <Target size={15} className="text-teams" aria-hidden />
                  What matters to your work?
                </h3>
                <p className="mt-0.5 text-[12.5px] text-muted">
                  {roleReady
                    ? `We’ve started you off for ${fn?.label ?? "your role"} in ${profile.industry}. Keep, remove or add — up to ${MAX_TOPICS}.`
                    : `Pick up to ${MAX_TOPICS}. Add your function and industry for suggestions tailored to your role.`}
                </p>
              </div>
              <span className={`shrink-0 text-[12px] font-semibold tabular-nums ${full ? "text-[#b5630f]" : "text-muted"}`} aria-live="polite">
                {profile.topics.length}/{MAX_TOPICS}
              </span>
            </div>

            {profile.topics.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-2" aria-label="Your selection">
                {profile.topics.map((t) => (
                  <SelectedChip key={t} label={t} suggested={suggestedSet.has(t)} onRemove={() => toggleTopic(t)} />
                ))}
              </div>
            )}

            {!full && roleReady && moreForRole.length > 0 && (
              <div className="mt-4">
                <p className="mb-1.5 text-[12px] font-semibold text-muted">More for your role</p>
                <div className="flex flex-wrap gap-2">
                  {moreForRole.map((t) => (
                    <AddChip key={t} label={t} disabled={full} onAdd={() => toggleTopic(t)} />
                  ))}
                </div>
              </div>
            )}

            {!full && moreThemes.length > 0 && (
              <div className="mt-4">
                <p className="mb-1.5 text-[12px] font-semibold text-muted">Broader themes</p>
                <div className="flex flex-wrap gap-2">
                  {moreThemes.map((t) => (
                    <AddChip key={t} label={t} disabled={full} onAdd={() => toggleTopic(t)} />
                  ))}
                </div>
              </div>
            )}

            <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1">
              <ExploreButton label={`Explore more topics (${countItems(TOPIC_CATALOG)}+)`} onClick={() => setExplore("topics")} />
              {profile.topicsCustomised && roleReady && (
                <button
                  type="button"
                  onClick={() => onChange({ topics: defaultSelection(profile.function, profile.industry), topicsCustomised: false })}
                  className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-[12.5px] font-medium text-muted hover:bg-white hover:text-navy"
                >
                  <RotateCcw size={12} aria-hidden /> Reset to suggestions
                </button>
              )}
              {full && <span className="text-[12px] text-[#9a5410]">All 6 chosen — remove one to see more suggestions.</span>}
            </div>
          </section>

          <section className="rounded-xl border border-line bg-white p-4 sm:p-5" aria-labelledby="interests-h">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 id="interests-h" className="flex items-center gap-2 text-[14px] font-semibold text-navy">
                  <Heart size={15} className="text-orange" aria-hidden />
                  Personal interests <span className="font-normal text-muted">(optional)</span>
                </h3>
                <p className="mt-0.5 text-[12.5px] text-muted">For lighter reads when you have a spare moment.</p>
              </div>
              <span className="shrink-0 text-[12px] font-semibold text-muted tabular-nums">
                {profile.interests.length}/{MAX_INTERESTS}
              </span>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {INTEREST_EXAMPLES.map((t) => (
                <Chip
                  key={t}
                  selected={profile.interests.includes(t)}
                  disabled={profile.interests.length >= MAX_INTERESTS}
                  onClick={() => toggleInterest(t)}
                >
                  {t}
                </Chip>
              ))}
              {extraInterests.map((t) => (
                <SelectedChip key={t} label={t} onRemove={() => toggleInterest(t)} />
              ))}
            </div>
            <div className="mt-3">
              <ExploreButton label={`Explore more interests (${countItems(INTEREST_CATALOG)}+)`} onClick={() => setExplore("interests")} />
            </div>
          </section>
        </div>
      </div>

      {explore === "topics" && (
        <ExploreDialog
          title="Explore topics"
          noun="topics"
          catalog={TOPIC_CATALOG}
          selected={profile.topics}
          max={MAX_TOPICS}
          onToggle={toggleTopic}
          onClose={() => setExplore(null)}
        />
      )}
      {explore === "interests" && (
        <ExploreDialog
          title="Explore interests"
          noun="interests"
          catalog={INTEREST_CATALOG}
          selected={profile.interests}
          max={MAX_INTERESTS}
          onToggle={toggleInterest}
          onClose={() => setExplore(null)}
        />
      )}
    </>
  );
}

