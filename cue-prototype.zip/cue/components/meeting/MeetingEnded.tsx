"use client";

import { ArrowRight, PhoneOff, RotateCcw } from "lucide-react";
import { Logo } from "@/components/shared/ui";
import { MEETING } from "@/lib/constants";
import { formatElapsed, useApp } from "@/lib/state";

export default function MeetingEnded() {
  const { state, returnToCue, joinMeeting } = useApp();
  const { joinedAt, leftAt } = state.meeting;
  const duration = joinedAt && leftAt ? formatElapsed(leftAt - joinedAt) : null;
  const read = state.readIds.length;
  const saved = state.savedIds.length;

  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-meet px-6 text-center text-white">
      <div className="flex h-16 w-16 animate-pop items-center justify-center rounded-full bg-white/10">
        <PhoneOff size={26} aria-hidden />
      </div>
      <h1 className="mt-6 animate-rise text-[28px] font-semibold">You left the meeting</h1>
      <p className="mt-1 text-[15px] text-white/60">
        {MEETING.title}
        {duration ? ` · ${duration}` : ""}
      </p>

      <div className="mt-8 flex animate-rise items-center gap-3 rounded-xl bg-white/5 px-5 py-3 text-[13.5px] text-white/80 ring-1 ring-white/10">
        <Logo dark className="text-[18px]" />
        <span>
          {read} {read === 1 ? "story" : "stories"} read · {saved} saved for later
        </span>
      </div>

      <div className="mt-8 flex flex-col gap-3 sm:flex-row">
        <button
          type="button"
          onClick={returnToCue}
          className="inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-white px-5 text-[14px] font-semibold text-navy hover:bg-ivory"
        >
          Return to Cue <ArrowRight size={16} aria-hidden />
        </button>
        <button
          type="button"
          onClick={joinMeeting}
          className="inline-flex h-11 items-center justify-center gap-2 rounded-lg px-5 text-[14px] font-semibold text-white ring-1 ring-white/25 hover:bg-white/10"
        >
          <RotateCcw size={15} aria-hidden /> Rejoin meeting
        </button>
      </div>
    </main>
  );
}
