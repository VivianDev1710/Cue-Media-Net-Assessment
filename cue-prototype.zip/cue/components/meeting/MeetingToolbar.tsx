"use client";

import {
  ChevronDown,
  Ellipsis,
  Hand,
  LayoutGrid,
  MessageSquare,
  MicOff,
  Phone,
  Shield,
  ShieldCheck,
  Smile,
  SquarePlus,
  User,
  VideoOff,
  WandSparkles,
  ArrowUpFromLine,
  type LucideIcon,
} from "lucide-react";
import type { ReactNode } from "react";

function ToolButton({
  icon: Icon,
  label,
  onClick,
  active,
  pressed,
  className = "",
  iconClass = "",
}: {
  icon: LucideIcon;
  label: string;
  onClick: () => void;
  active?: boolean;
  pressed?: boolean;
  className?: string;
  iconClass?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={pressed}
      className={`flex h-[58px] min-w-[58px] flex-col items-center justify-center gap-1 rounded-md px-2 text-[12px] text-white/85 hover:bg-white/10 hover:text-white ${
        active ? "bg-white/10 text-white" : ""
      } ${className}`}
    >
      <Icon size={21} strokeWidth={1.6} className={iconClass} aria-hidden />
      <span>{label}</span>
    </button>
  );
}

function Caret({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      className="flex h-[58px] w-6 items-center justify-center rounded-md text-white/70 hover:bg-white/10"
    >
      <ChevronDown size={15} aria-hidden />
    </button>
  );
}

export interface ToolbarHandlers {
  onChat: () => void;
  onPeople: () => void;
  onRaise: () => void;
  onReact: () => void;
  onUnavailable: (feature: string) => void;
  onCamera: () => void;
  onMic: () => void;
  onLeave: () => void;
}

export default function MeetingToolbar({
  elapsed,
  panel,
  raised,
  handlers,
  reactPopover,
}: {
  elapsed: string;
  panel: "chat" | "people" | null;
  raised: boolean;
  handlers: ToolbarHandlers;
  reactPopover?: ReactNode;
}) {
  const h = handlers;
  return (
    <div className="flex h-[72px] shrink-0 items-center gap-3 border-b border-white/10 bg-meet-bar px-3 text-white sm:px-4">
      <div className="flex items-center gap-3 text-white/80">
        <Shield size={20} strokeWidth={1.6} aria-label="Meeting secured" className="hidden sm:block" />
        <span className="hidden h-7 w-9 items-center justify-center rounded-full ring-1 ring-white/40 sm:flex" aria-hidden>
          <WandSparkles size={15} strokeWidth={1.6} />
        </span>
        <span className="text-[15px] tabular-nums" aria-label={`Meeting time ${elapsed}`}>
          {elapsed}
        </span>
      </div>
      <div className="flex-1" />
      <div className="flex items-center overflow-x-auto [scrollbar-width:none]">
        <ToolButton icon={MessageSquare} label="Chat" onClick={h.onChat} active={panel === "chat"} pressed={panel === "chat"} />
        <ToolButton icon={User} label="People" onClick={h.onPeople} active={panel === "people"} pressed={panel === "people"} />
        <ToolButton
          icon={Hand}
          label={raised ? "Lower" : "Raise"}
          onClick={h.onRaise}
          active={raised}
          pressed={raised}
          iconClass={raised ? "text-[#f2c94c]" : ""}
        />
        <div className="relative">
          <ToolButton icon={Smile} label="React" onClick={h.onReact} />
          {reactPopover}
        </div>
        <ToolButton icon={LayoutGrid} label="View" onClick={() => h.onUnavailable("View options")} className="hidden md:flex" />
        <ToolButton icon={ShieldCheck} label="Controls" onClick={() => h.onUnavailable("Meeting controls")} className="hidden lg:flex" />
        <ToolButton icon={SquarePlus} label="Apps" onClick={() => h.onUnavailable("Apps")} className="hidden lg:flex" />
        <ToolButton icon={Ellipsis} label="More" onClick={() => h.onUnavailable("More options")} className="hidden md:flex" />
        <span className="mx-2 h-9 w-px bg-white/20" aria-hidden />
        <ToolButton icon={VideoOff} label="Camera" onClick={h.onCamera} />
        <Caret label="Camera options" onClick={() => h.onUnavailable("Camera options")} />
        <ToolButton
          icon={MicOff}
          label="Mic"
          onClick={h.onMic}
          className="ring-2 ring-white/90 ring-inset"
        />
        <Caret label="Microphone options" onClick={() => h.onUnavailable("Audio options")} />
        <ToolButton icon={ArrowUpFromLine} label="Share" onClick={() => h.onUnavailable("Screen sharing")} className="hidden sm:flex" />
        <span className="mx-2 h-9 w-px bg-white/20" aria-hidden />
        <ToolButton icon={Phone} label="Leave" onClick={h.onLeave} iconClass="rotate-[135deg] text-[#e5555b]" />
        <Caret label="Leave options" onClick={h.onLeave} />
      </div>
    </div>
  );
}
