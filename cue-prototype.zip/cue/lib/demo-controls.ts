/**
 * Prototype-only demo controls.
 * Open the panel with Shift + D (when not typing in a field) or add ?demo=1 to the URL
 * to show a small "Demo" button in the bottom-left corner.
 */
export const DEMO_SHORTCUT = { key: "D", shift: true } as const;

export function isDemoShortcut(e: KeyboardEvent): boolean {
  const target = e.target as HTMLElement | null;
  const typing =
    target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT" || target.isContentEditable);
  return !typing && e.shiftKey && !e.metaKey && !e.ctrlKey && e.key.toUpperCase() === DEMO_SHORTCUT.key;
}

export function demoParamPresent(): boolean {
  if (typeof window === "undefined") return false;
  return new URLSearchParams(window.location.search).has("demo");
}

export const DEMO_PROFILE = {
  name: "Vivian Joseph",
  function: "operations",
  seniority: "Director",
  industry: "Manufacturing",
  topics: ["Supply chain & operations", "Manufacturing", "Industrial policy & PLI", "Supply chain resilience", "Technology & AI"],
  interests: ["Geopolitics", "Economy", "Football"],
};
