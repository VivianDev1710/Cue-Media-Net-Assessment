"use client";

import { useApp } from "@/lib/state";

export default function Toasts() {
  const { toasts } = useApp();
  return (
    <div className="pointer-events-none fixed inset-x-0 top-16 z-[80] flex flex-col items-center gap-2 px-4" aria-live="polite" role="status">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`animate-rise rounded-lg px-4 py-2.5 text-[13px] font-medium shadow-lg ${
            t.tone === "dark" ? "bg-[#2d2d2d] text-white ring-1 ring-white/10" : "bg-navy text-white"
          }`}
        >
          {t.text}
        </div>
      ))}
    </div>
  );
}
