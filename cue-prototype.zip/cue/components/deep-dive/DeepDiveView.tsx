"use client";

import { ArrowLeft, ArrowRight, BookOpen, Check, ChevronDown, Clock, Users } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { Paragraphs, PersonaBox, SaveButton, Section, SourceLine } from "@/components/brief/StoryParts";
import StoryVisual from "@/components/shared/StoryVisual";
import { Button } from "@/components/shared/ui";
import { copy, getStory } from "@/lib/content";
import { otherPersonas, resolvePersona } from "@/lib/persona";
import { deepDiveMinutes } from "@/lib/reading-time";
import { useApp } from "@/lib/state";
import type { BriefSection } from "@/types/story";

export const SCROLL_ROOT_ID = "cue-scroll";

const slug = (s: string) => "dd-" + s.toLowerCase().replace(/[^a-z0-9]+/g, "-");
const SHORT: Record<string, string> = {
  "The story in brief": "At a glance",
  "Background and history": "Background",
  "Key concepts explained": "Key concepts",
  "The longer story": "The longer story",
  "What this does not mean": "What it doesn’t mean",
  "What it means by sector": "By sector",
  "Risks and opportunities": "Risks & opportunities",
  "Scenarios to plan for": "Scenarios",
  "An illustrative example": "An example",
  "What happens next": "What’s next",
  "Questions to ask your team": "Questions for your team",
};
const WIM_ID = "dd-why-it-matters-to-you";

/** Highlights the section currently in view inside the app's scroll container. */
function useScrollSpy(ids: string[]) {
  const [active, setActive] = useState(ids[0]);
  const lock = useRef(0);

  useEffect(() => {
    const root = document.getElementById(SCROLL_ROOT_ID);
    if (!root) return;
    let frame = 0;
    const compute = () => {
      frame = 0;
      if (Date.now() < lock.current) return;
      const top = root.getBoundingClientRect().top;
      let current = ids[0];
      for (const id of ids) {
        const el = document.getElementById(id);
        if (el && el.getBoundingClientRect().top - top <= 140) current = id;
      }
      if (root.scrollTop + root.clientHeight >= root.scrollHeight - 8) current = ids[ids.length - 1];
      setActive(current);
    };
    const onScroll = () => {
      if (!frame) frame = requestAnimationFrame(compute);
    };
    compute();
    root.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      root.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      if (frame) cancelAnimationFrame(frame);
    };
  }, [ids]);

  const jump = useCallback((id: string) => {
    const root = document.getElementById(SCROLL_ROOT_ID);
    const el = document.getElementById(id);
    if (!root || !el) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const y = el.getBoundingClientRect().top - root.getBoundingClientRect().top + root.scrollTop - 20;
    setActive(id);
    lock.current = Date.now() + 700; // keep the clicked item highlighted while smooth-scrolling
    root.scrollTo({ top: y, behavior: reduce ? "auto" : "smooth" });
  }, []);

  return { active, jump };
}

export default function DeepDiveView() {
  const { state, openStory, markReadAndNext } = useApp();
  const [teamOpen, setTeamOpen] = useState(true);
  const navRef = useRef<HTMLUListElement>(null);
  const story = getStory(state.reader.storyId);

  const sections = story?.deepDive ?? [];
  const intro = sections.find((s) => /story in brief/i.test(s.heading)) ?? sections[0];
  const takeaway = sections.find((s) => /takeaway/i.test(s.heading));
  const body = sections.filter((s) => s !== intro && s !== takeaway);
  // "Why it matters to you" follows the big-picture framing (storyboard order)
  const anchorIdx = Math.max(
    body.findIndex((s) => /does not mean/i.test(s.heading)),
    body.findIndex((s) => /bigger picture/i.test(s.heading)),
  );
  const split = anchorIdx >= 0 ? anchorIdx + 1 : Math.min(2, body.length);
  const beforeWim = body.slice(0, split);
  const afterWim = body.slice(split);

  const nav: { id: string; label: string }[] = intro
    ? [
        { id: slug(intro.heading), label: SHORT[intro.heading] ?? intro.heading },
        ...beforeWim.map((s) => ({ id: slug(s.heading), label: SHORT[s.heading] ?? s.heading })),
        { id: WIM_ID, label: "Why it matters to you" },
        ...afterWim.map((s) => ({ id: slug(s.heading), label: SHORT[s.heading] ?? s.heading })),
        ...(takeaway ? [{ id: slug(takeaway.heading), label: "Key takeaway" }] : []),
      ]
    : [];
  const navKey = nav.map((n) => n.id).join("|");
  const ids = useStableIds(navKey);
  const { active, jump } = useScrollSpy(ids);

  // Keep the active nav item visible inside the sticky nav (without moving the page)
  useEffect(() => {
    const list = navRef.current;
    const item = list?.querySelector<HTMLElement>(`[data-id="${active}"]`);
    if (!list || !item) return;
    if (item.offsetTop < list.scrollTop || item.offsetTop + item.offsetHeight > list.scrollTop + list.clientHeight) {
      list.scrollTop = item.offsetTop - list.clientHeight / 2;
    }
  }, [active]);

  if (!story) {
    return <p className="px-8 py-24 text-center text-muted">{copy("story unavailable state", "This story isn’t available right now.")}</p>;
  }
  if (!sections.length || !intro) {
    return (
      <div className="px-8 py-24 text-center text-muted">
        <p>A deep dive isn’t available for this story yet.</p>
        <Button variant="secondary" className="mt-4" onClick={() => openStory(story.id, "brief")}>
          Back to the 2-minute brief
        </Button>
      </div>
    );
  }

  const { implication } = resolvePersona(story, state.profile.function, state.profile.seniority);
  const peers = otherPersonas(story, implication);
  const minutes = deepDiveMinutes(story);
  const renderSection = (s: BriefSection) => <Section key={s.heading} id={slug(s.heading)} section={s} />;
  const activeIdx = nav.findIndex((n) => n.id === active);

  return (
    <article className="mx-auto max-w-[1080px] px-5 pt-6 pb-24 sm:px-10">
      <div className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => openStory(story.id, "brief")}
          className="inline-flex items-center gap-1.5 rounded-md px-1 py-1 text-[13.5px] font-semibold text-navy hover:text-teams"
        >
          <ArrowLeft size={16} aria-hidden /> Back to 2-minute brief
        </button>
        <SaveButton story={story} withLabel />
      </div>

      <header className="mt-6 grid gap-6 md:grid-cols-[minmax(0,1fr)_280px] md:items-end">
        <div>
          <p className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[13px] text-muted">
            <span className="inline-flex items-center gap-1 font-semibold text-orange">
              <BookOpen size={14} aria-hidden /> Deep dive
            </span>
            <span className="inline-flex items-center gap-1">
              <Clock size={13} aria-hidden /> {minutes} min read
            </span>
            <span className="font-medium text-teams">{story.category}</span>
          </p>
          <h1 className="mt-3 font-serif text-[32px] leading-[1.15] font-semibold text-navy sm:text-[40px]">{story.headline}</h1>
          <p className="mt-3 text-[15px] text-muted">From the basics to business impact — with implications for you, scenarios and what to watch next.</p>
        </div>
        <StoryVisual story={story} className="hidden h-[170px] rounded-xl md:block" iconSize={52} />
      </header>

      <div className="mt-10 grid gap-10 lg:grid-cols-[210px_minmax(0,1fr)]">
        <nav aria-label="Deep dive sections" className="hidden lg:block">
          <div className="sticky top-6">
            <p className="mb-2 pl-4 text-[11px] font-semibold tracking-[0.1em] text-muted uppercase">
              In this deep dive · {Math.max(activeIdx + 1, 1)}/{nav.length}
            </p>
            <ul ref={navRef} className="relative max-h-[calc(100vh-200px)] space-y-0.5 overflow-y-auto border-l border-line [scrollbar-width:thin]">
              {nav.map((n) => {
                const on = n.id === active;
                return (
                  <li key={n.id} data-id={n.id}>
                    <button
                      type="button"
                      onClick={() => jump(n.id)}
                      aria-current={on ? "location" : undefined}
                      className={`-ml-px block w-full border-l-2 px-4 py-1.5 text-left text-[13px] transition-colors ${
                        on ? "border-orange font-semibold text-navy" : "border-transparent text-muted hover:border-navy/30 hover:text-navy"
                      } ${n.id === WIM_ID && !on ? "text-[#9a5410]" : ""}`}
                    >
                      {n.label}
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        </nav>

        <div className="max-w-[720px] space-y-10">
          <section id={slug(intro.heading)} className="scroll-mt-6">
            <h2 className="text-[13px] font-semibold tracking-[0.08em] text-navy uppercase">At a glance</h2>
            <Paragraphs text={intro.body} className="mt-2 font-serif text-[19px] leading-[1.6] text-navy" />
          </section>

          {beforeWim.map(renderSection)}

          <section id={WIM_ID} className="scroll-mt-6 space-y-4">
            <PersonaBox story={story} detailed />
            {peers.length > 0 && (
              <div className="rounded-xl border border-line bg-white">
                <button
                  type="button"
                  onClick={() => setTeamOpen((v) => !v)}
                  aria-expanded={teamOpen}
                  className="flex w-full items-center gap-2 px-5 py-3.5 text-left text-[14px] font-semibold text-navy"
                >
                  <Users size={16} className="text-teams" aria-hidden />
                  How it lands across your leadership team
                  <ChevronDown size={16} className={`ml-auto transition-transform ${teamOpen ? "rotate-180" : ""}`} aria-hidden />
                </button>
                {teamOpen && (
                  <dl className="grid gap-5 border-t border-line px-5 py-5 sm:grid-cols-2">
                    {peers.map((p) => (
                      <div key={p.key}>
                        <dt className="text-[12.5px] font-semibold text-navy">{p.label}</dt>
                        <dd className="mt-1 text-[14px] leading-relaxed text-[#3d4a5f]">{p.body}</dd>
                      </div>
                    ))}
                  </dl>
                )}
              </div>
            )}
          </section>

          {afterWim.map(renderSection)}

          {takeaway && (
            <section id={slug(takeaway.heading)} className="scroll-mt-6 rounded-xl bg-navy p-6 text-white">
              <h2 className="text-[12px] font-semibold tracking-[0.12em] text-orange uppercase">Key takeaway</h2>
              <Paragraphs text={takeaway.body} className="mt-2 font-serif text-[20px] leading-[1.5]" />
            </section>
          )}

          <div className="border-t border-line pt-5">
            <SourceLine story={story} />
            <p className="mt-2 text-[12px] text-muted">
              Sections labelled “Cue analysis” explain and extend the reporting; they add no new reported facts, and illustrative examples use hypothetical numbers.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <Button size="lg" onClick={() => markReadAndNext(story.id, "reader")}>
              <Check size={17} aria-hidden /> Mark as read &amp; next <ArrowRight size={16} aria-hidden />
            </Button>
            <Button size="lg" variant="secondary" onClick={() => openStory(story.id, "brief")}>
              <ArrowLeft size={16} aria-hidden /> Back to brief
            </Button>
          </div>
        </div>
      </div>
    </article>
  );
}

/** Returns the same array instance while the joined key is unchanged (keeps the scroll-spy effect stable). */
function useStableIds(key: string): string[] {
  const ref = useRef<{ key: string; ids: string[] }>({ key: "", ids: [] });
  if (ref.current.key !== key) ref.current = { key, ids: key ? key.split("|") : [] };
  return ref.current.ids;
}
