import type { Story } from "@/types/story";

export interface QueueState {
  readIds: string[];
  snoozedIds: string[];
  hiddenToday: Record<string, string>; // id → yyyy-mm-dd
  pinnedStoryId: string | null;
}

export const todayKey = () => new Date().toLocaleDateString("en-CA"); // yyyy-mm-dd, local time

export function isHiddenToday(id: string, hidden: Record<string, string>): boolean {
  return hidden[id] === todayKey();
}

/**
 * Deterministic queue:
 *  1. Ranked order from the content library.
 *  2. Skip read stories and stories hidden for today.
 *  3. Stories the user said "Not now" to move to the end (in the order they were snoozed).
 *  4. A demo-pinned story (Jump to story) goes first.
 */
export function buildQueue(stories: Story[], s: QueueState): Story[] {
  const eligible = stories.filter((x) => !s.readIds.includes(x.id) && !isHiddenToday(x.id, s.hiddenToday));
  const fresh = eligible.filter((x) => !s.snoozedIds.includes(x.id));
  const snoozed = s.snoozedIds
    .map((id) => eligible.find((x) => x.id === id))
    .filter((x): x is Story => Boolean(x));
  let queue = [...fresh, ...snoozed];
  if (s.pinnedStoryId) {
    const pinned = queue.find((x) => x.id === s.pinnedStoryId);
    if (pinned) queue = [pinned, ...queue.filter((x) => x.id !== pinned.id)];
  }
  return queue;
}

/** Next unread story after `currentId` in ranked order (wrapping to any earlier unread one). */
export function nextAfter(stories: Story[], currentId: string, s: QueueState): Story | null {
  const queue = buildQueue(stories, { ...s, pinnedStoryId: null }).filter((x) => x.id !== currentId);
  if (!queue.length) return null;
  const idx = stories.findIndex((x) => x.id === currentId);
  const later = queue.find((x) => stories.findIndex((y) => y.id === x.id) > idx && !s.snoozedIds.includes(x.id));
  return later ?? queue[0];
}
