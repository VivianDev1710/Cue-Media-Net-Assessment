# cue. — interactive prototype

Cue is a contextual news product for busy executives: **be present when attention is available, never demand attention when work comes first.**
This prototype simulates the full journey: setup → permissions → Teams invitation → waiting room with an in-meeting cue → 2-minute brief → 5-minute deep dive → saved stories → leaving the meeting.

There is no backend, no AI calls, no Microsoft integration and no authentication. All content comes from a static Markdown library that is compiled to JSON at build time. All user state lives in the browser's `localStorage`.

---

## Brand

The supplied **cue.** wordmark is embedded in `lib/logo.ts` (navy, plus a white variant for dark screens) and used by the `Logo` component everywhere. The favicon is `app/icon.png`.

## Run locally

Requires Node 18.18+ (Node 20 or 22 recommended).

```bash
npm install
npm run dev          # http://localhost:3000  (runs build-content first)
```

Production build check:

```bash
npm run build && npm start
```

## Deploy to Vercel

1. Push this folder to a GitHub/GitLab/Bitbucket repository (or run `npx vercel` from the folder).
2. In Vercel, **Add New → Project**, import the repo. The framework preset is detected as **Next.js**. Leave the build command as `npm run build` and the output setting as default.
3. Deploy. No environment variables are needed.

`npm run build` runs `prebuild` → `npm run build-content`, which regenerates `data/stories.json` from the Markdown. `data/stories.json` is also committed, so the build still works if the Markdown is missing.

## Replace the daily news file

1. Overwrite `data/cue_news_today.md` with the new daily file (same structure, described below).
2. Run `npm run build-content`. The script prints every story it found with section counts, plus warnings for missing fields.
3. Commit both `data/cue_news_today.md` and `data/stories.json`, then redeploy. Vercel rebuilds the JSON anyway.

**Expected Markdown structure** (the parser in `lib/content-parser.ts` reads these headings, not line positions):

| Element | Format |
|---|---|
| Header bullets | `- **Date:** …`, `- **Generated timestamp:** …` before the first `##` |
| Ranking | any table row `\| rank \| CUE-xxx \| …` (used for queue order) |
| Full story | `## CUE-001 — Headline` |
| Metadata | `### Metadata` with `- **Category:**`, `- **Source:**`, `- **Direct URL:**`, `- **Corroborating source:** Name — URL`, `- **Publication date/time:**`, `- **Importance:**`, optional `- **Image:** /path-or-url` |
| 20-second cue | `### 20-second cue` (an optional bold headline line, then the text) |
| Card summary | `### Cue card summary`: a 200–230 character takeaway of the whole article, shown on the in-meeting card (falls back to the 20-second cue) |
| Briefs | `### 2-minute brief — Standard` / `### 2-minute brief — Too technical`, each followed by `###` sections |
| Deep dive | `### 10-minute deep dive` (any `### N-minute deep dive` works) followed by `###` sections (`The story in brief`, `Background and history`, `The bigger picture`, `Key implications`, `Risks and opportunities`, `What happens next`, `Key takeaway`) |
| Personas | `### Why it matters to you` with `#### CEO / …`, `#### CFO / …`, `#### COO / …`, `#### CTO / …`, `#### CMO / …`, `#### CHRO / …` |
| Backups | `### CUE-B01 — Headline` inside `## Backup Stories` |
| UI copy | bullets inside `## Prototype Interaction Copy` (e.g. not-interested confirmation, caught-up text) |

Stories with missing pieces do not crash the app. For example, a story without a simplified brief hides the "Too technical" action, and a missing persona falls back to the closest available one with a label. If no stories can be parsed, the app shows a developer error screen.

## Demo controls (prototype only)

Not visible in the normal UI.

- **Shift + D** (when not typing in a field) toggles the demo panel, **or**
- open the app with **`?demo=1`** to show a small "Demo" launcher in the bottom-left corner.

| Control | What it does |
|---|---|
| Skip setup | Fills a sample profile (Supply Chain & Operations · Director · Manufacturing) and goes to "You're all set" (invite follows in 2s) |
| Trigger Teams invitation | Shows the bottom-right meeting prompt |
| Join meeting now | Enters the simulated meeting |
| Second participant joins now | Adds Alex Morgan immediately |
| Jump to story | Pins a chosen story to the front of the queue and opens its brief |
| Reset prototype | Clears all local state |

**Suggested 3-minute demo:** load `?demo=1`, complete setup (≈45s), let the invite appear, Join, read the cue, *Know more* → *Too technical* → *Deep dive*, show the role-specific "Why it matters to you", then wait for Alex to join at 30s while reading (or use *Second participant joins now*). The meeting banner updates without interrupting you. *Return to meeting*, *Mark as read & next*, save a story, Leave → Return to Cue → Saved.

## How the experience works

- **Setup (≈45–60s)**: searchable dropdowns for **Function** (12), **Seniority** (9) and **Industry** (48), then one unified **What matters to your work?** section, capped at **6** items in total. Once function and industry are set, 4 items are pre-selected: the function's broad theme plus the top 3 role topics. The rest are offered as *More for your role* and *Broader themes*, and **Explore more topics** searches 136 themes and topics. Personal interests are a separate, optional panel (up to 5, 105+ to explore). Full flow and rules are in `docs/ACCEPTANCE_CRITERIA.md`. Teams is required on step 2; Chrome is optional.
- **Invite**: appears exactly 2s after "You're all set". It plays a subtle chime generated with the Web Audio API. If the browser blocks audio, it stays silent. You can toggle sound on the invite and in Settings.
- **Meeting**: camera and mic are off, and there is no pre-join screen. Timings are fixed and restart on every join: the **cue card appears 2s after joining**, sliding up and fading in over 360ms, and **Alex Morgan joins at 30s**. Chat and People panels, Raise and React work. View, Controls, Apps, More, Share and the option carets show a "not available in this prototype" notice. When Alex joins (camera and mic off), "No one has started speaking yet." appears above the Cue card.
- **Cue card**: shows a 2–3 line summary of the whole article (the `### Cue card summary` field in the Markdown). The × in the top-right minimises it to the pill without dismissing the story.
- **Restarting**: "Go to beginning of user journey" on the *You're all set* screen, **Reset prototype** in the left navigation (with confirmation) and Settings → Reset all clear everything and return to setup step 1.
- **Queue**: ranked order from the library, skipping read stories and those hidden for today. *Not now* moves a story to the end of the queue. If it was the last one left, the card minimises to a pill. The ••• menu offers *Don't show this today* and *Minimise*.
- **Reading**: opening a brief keeps the meeting running. A slim banner shows the timer, who joined and the speaking status, with *Return to meeting*. Scroll position is remembered per view.
- **Why it matters to you**: chosen from the six supplied personas by **function**, and labelled with function and seniority (e.g. "For you in Finance & Investment · Director"). Sales & BD → CMO / Commercial / Growth; Procurement → COO / Supply Chain / Operations. Product & Design → CTO, and Legal & Compliance, Consulting and Other → CEO, each labelled as the closest available perspective. The deep dive also shows the other five personas under "How it lands across your leadership team".
- **Deep dives (10 min)**: every deep dive is 2,000+ words. Reading time is computed from the words on the page at 200 wpm (`lib/reading-time.ts`), not hard-coded. The section list on the left follows your scroll and jumps to a section on click.
- **Persistence (`localStorage`, key `cue-prototype-state-v1`)**: setup, profile, permissions, read, saved, snoozed and hidden-today IDs, not-interested feedback, sound, meeting timer and participant state. Corrupt or unknown data is discarded safely.

## Single-page artifact build

`npm run build-artifact` bundles the app with esbuild and Tailwind into one self-contained `artifact/index.html`. That is the file published as the claude.ai artifact. The Vercel deployment does not use it.

## Project structure

```
app/                 layout, page, global styles (Tailwind v4 theme tokens), icon
components/
  setup/             profile & permissions steps, setup-complete
  meeting/           invite, toolbar, meeting screen, banner, meeting ended
  news/              in-meeting Cue card
  app/               Cue reading shell (sidebar + views)
  brief/             2-minute brief + shared story parts
  deep-dive/         5-minute deep dive
  saved/ settings/   Saved and Settings views
  shared/            UI primitives, brand glyphs, story visual, toasts, demo panel
data/                cue_news_today.md (source) → stories.json (generated)
lib/                 content parser/loader, queue, persona, state (React context), storage, sound, demo controls
scripts/             build-content.ts
types/               story model
```

## Deep-dive extensions (editorial)

The original Markdown deep dives were about 300 words, roughly a 1.5-minute read. To make each a genuine 10-minute read, Cue added sections to every story: *Key concepts explained*, *The longer story*, *What this does not mean*, *What it means by sector*, *Scenarios to plan for*, *An illustrative example*, *Signals to track*, *Questions to ask your team*, *Common questions*, and for some stories a *Glossary*. They live in `scripts/deep-dive-extensions/CUE-xxx.md` and are merged into `data/cue_news_today.md` by `python3 scripts/merge-deep-dive-extensions.py`. The script is safe to re-run. Each added section carries a `<!-- Cue analysis … -->` marker, which the app shows as a small **Cue analysis** label. These sections explain and build on the reported facts. They add no new reported claims, and their examples use hypothetical round numbers. For a new daily file, either ask the content generator for 2,000-word deep dives or write matching extension files and run the merge script.

## Limitations and content notes

- **No images in the library.** None of the 8 stories has an image field, so each one gets an original generated visual (subject icon on a navy field). Add `- **Image:** /images/foo.jpg` to a story's Metadata to use a real image.
- **8 full stories, not 30.** The supplied file states that it holds 8 complete packages plus 32 backup candidates. Backups are parsed into `stories.json` but not shown, since Cue is not a feed.
- **Older saved state.** A browser that saved the earlier role-based profile is sent back through setup, keeping name and answers where they map.
- **One paragraph per persona.** The library has one paragraph per role, so the deep dive's "Why it matters to you" uses that paragraph (shown larger) plus the other roles' views. It does not generate new text.
- **Duplicate corroborating sources.** For CUE-004 and CUE-005 the corroborating source is the same Reuters URL as the primary, so only one link is shown.
- **Ranking table formatting.** The first ranking table in the Markdown has a malformed separator row. The parser ignores separators, so this is harmless.
- **Not interested** records feedback locally and shows the confirmation. It does not reorder the queue.
- **Simulated only.** There is no real Teams or Chrome integration, speech detection, video or chat. There is no real "today" boundary beyond the local date used for *Don't show this today*.
- Fonts use system stacks (Segoe UI / Iowan Old Style / Georgia), so nothing is fetched at build time.
