"use client";

import { FlaskConical, X } from "lucide-react";
import { useEffect, useState } from "react";
import { stories } from "@/lib/content";
import { demoParamPresent, isDemoShortcut } from "@/lib/demo-controls";
import { useApp } from "@/lib/state";

/** Prototype-only controls. Shift + D toggles; ?demo=1 shows a small launcher. Not part of the product UI. */
export default function DemoPanel() {
  const app = useApp();
  const { state } = app;
  const [open, setOpen] = useState(false);
  const [launcher, setLauncher] = useState(false);
  const [jump, setJump] = useState(stories[0]?.id ?? "");

  useEffect(() => {
    setLauncher(demoParamPresent());
    const onKey = (e: KeyboardEvent) => {
      if (isDemoShortcut(e)) {
        e.preventDefault();
        setOpen((v) => !v);
      } else if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const item = "w-full rounded-md px-3 py-2 text-left text-[13px] hover:bg-white/10 disabled:opacity-40 disabled:hover:bg-transparent";

  return (
    <>
      {launcher && !open && (
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="fixed bottom-3 left-3 z-[90] inline-flex items-center gap-1.5 rounded-full bg-black/70 px-3 py-1.5 text-[11.5px] font-semibold text-white/85 hover:bg-black"
        >
          <FlaskConical size={13} aria-hidden /> Demo
        </button>
      )}
      {open && (
        <div
          role="dialog"
          aria-label="Prototype demo controls"
          className="fixed bottom-3 left-3 z-[90] w-[290px] animate-rise rounded-xl bg-[#111827] p-3 text-white shadow-2xl ring-1 ring-white/15"
        >
          <div className="mb-2 flex items-center justify-between px-1">
            <p className="flex items-center gap-1.5 text-[12px] font-semibold tracking-wide text-orange uppercase">
              <FlaskConical size={13} aria-hidden /> Demo controls
            </p>
            <button type="button" onClick={() => setOpen(false)} aria-label="Close demo controls" className="rounded p-1 text-white/60 hover:bg-white/10">
              <X size={14} />
            </button>
          </div>
          <p className="px-1 pb-2 text-[11px] text-white/45">Stage: {state.stage} · Shift + D to toggle</p>
          <div className="space-y-0.5">
            <button type="button" className={item} onClick={app.demoSkipSetup}>
              Skip setup (sample profile)
            </button>
            <button type="button" className={item} disabled={!state.setupCompleted} onClick={app.showInvite}>
              Trigger Teams invitation
            </button>
            <button type="button" className={item} disabled={!state.setupCompleted} onClick={app.joinMeeting}>
              Join meeting now
            </button>
            <button
              type="button"
              className={item}
              disabled={state.stage !== "meeting" || Boolean(state.meeting.participantJoinedAt)}
              onClick={app.participantJoin}
            >
              Second participant joins now
            </button>
            <div className="flex items-center gap-2 px-3 py-2">
              <select
                value={jump}
                onChange={(e) => setJump(e.target.value)}
                aria-label="Story to jump to"
                className="min-w-0 flex-1 rounded-md bg-white/10 px-2 py-1.5 text-[12.5px] text-white"
              >
                {stories.map((s) => (
                  <option key={s.id} value={s.id} className="text-navy">
                    {s.id} — {s.headline.slice(0, 34)}…
                  </option>
                ))}
              </select>
              <button
                type="button"
                disabled={!state.setupCompleted}
                onClick={() => app.demoJumpToStory(jump)}
                className="rounded-md bg-white/15 px-2.5 py-1.5 text-[12.5px] font-semibold hover:bg-white/25 disabled:opacity-40"
              >
                Jump
              </button>
            </div>
            <button
              type="button"
              className={`${item} text-[#fca5a5]`}
              onClick={() => {
                app.reset();
                setOpen(false);
              }}
            >
              Reset prototype
            </button>
          </div>
        </div>
      )}
    </>
  );
}
