"use client";

import { Bookmark, CalendarClock, House, RotateCcw, Settings, Video, type LucideIcon } from "lucide-react";
import { useLayoutEffect, useRef, useState } from "react";
import ResetDialog from "@/components/shared/ResetDialog";
import BriefView from "@/components/brief/BriefView";
import DeepDiveView from "@/components/deep-dive/DeepDiveView";
import MeetingBanner from "@/components/meeting/MeetingBanner";
import SavedView from "@/components/saved/SavedView";
import SettingsView from "@/components/settings/SettingsView";
import { Avatar, Logo } from "@/components/shared/ui";
import { MEETING } from "@/lib/constants";
import { functionById } from "@/lib/taxonomy";
import { initials, useApp, type ReaderScreen } from "@/lib/state";

/** Remembers scroll position per view so returning to a story resumes where you were. */
const scrollMemory = new Map<string, number>();

function NavItem({
  icon: Icon,
  label,
  active,
  onClick,
  badge,
}: {
  icon: LucideIcon;
  label: string;
  active: boolean;
  onClick: () => void;
  badge?: number;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-current={active ? "page" : undefined}
      className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-[14px] font-medium transition-colors md:w-full ${
        active ? "bg-[#eceaf6] text-navy" : "text-muted hover:bg-navy/5 hover:text-navy"
      }`}
    >
      <Icon size={17} aria-hidden className={active ? "text-teams" : ""} />
      <span>{label}</span>
      {badge ? (
        <span className="ml-auto rounded-full bg-navy/10 px-1.5 text-[11px] font-semibold text-navy">{badge}</span>
      ) : null}
    </button>
  );
}

export default function CueApp() {
  const { state, openScreen, joinMeeting } = useApp();
  const { reader, stage, profile } = state;
  const inMeeting = stage === "meeting";
  const scrollRef = useRef<HTMLDivElement>(null);
  const [resetOpen, setResetOpen] = useState(false);
  const viewKey = `${reader.screen}:${reader.storyId ?? "head"}:${reader.simplified ? "s" : "n"}`;

  useLayoutEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = scrollMemory.get(viewKey) ?? 0;
  }, [viewKey]);

  const go = (s: ReaderScreen) => openScreen(s);
  const navScreen = reader.screen === "deep" ? "brief" : reader.screen;
  const fnLabel = functionById(profile.function)?.label;
  const roleLine = [profile.seniority, fnLabel].filter(Boolean).join(" · ");

  return (
    <div className="flex h-screen flex-col bg-ivory">
      {inMeeting && <MeetingBanner />}
      <div className="flex min-h-0 flex-1 flex-col md:flex-row">
        <aside className="flex shrink-0 items-center gap-2 border-b border-line bg-white px-3 py-2 md:w-[220px] md:flex-col md:items-stretch md:gap-1 md:border-r md:border-b-0 md:px-3 md:py-5">
          <div className="hidden px-3 pb-5 md:block">
            <Logo className="text-[28px]" />
          </div>
          <Logo className="mr-2 text-[22px] md:hidden" />
          <nav className="flex min-w-0 gap-1 overflow-x-auto md:flex-col md:overflow-visible" aria-label="Cue">
            <NavItem icon={House} label="Your Brief" active={navScreen === "brief"} onClick={() => go("brief")} />
            <NavItem icon={Bookmark} label="Saved" active={navScreen === "saved"} onClick={() => go("saved")} badge={state.savedIds.length} />
            <NavItem icon={Settings} label="Settings" active={navScreen === "settings"} onClick={() => go("settings")} />
            <NavItem icon={RotateCcw} label="Reset prototype" active={false} onClick={() => setResetOpen(true)} />
          </nav>

          {!inMeeting && state.setupCompleted && (
            <div className="mt-6 hidden rounded-xl border border-line bg-ivory/70 p-3 md:block">
              <p className="flex items-center gap-1.5 text-[11px] font-semibold tracking-wide text-muted uppercase">
                <CalendarClock size={13} aria-hidden /> Up next
              </p>
              <p className="mt-1.5 text-[14px] font-semibold text-navy">{MEETING.title}</p>
              <p className="text-[12px] text-muted">{MEETING.time}</p>
              <button
                type="button"
                onClick={joinMeeting}
                className="mt-2.5 inline-flex h-8 w-full items-center justify-center gap-1.5 rounded-md bg-teams text-[13px] font-semibold text-white hover:bg-[#5254a0]"
              >
                <Video size={14} aria-hidden /> Join in Teams
              </button>
            </div>
          )}
          {!inMeeting && state.setupCompleted && (
            <button
              type="button"
              onClick={joinMeeting}
              className="ml-auto inline-flex h-8 items-center gap-1.5 rounded-md bg-teams px-3 text-[12.5px] font-semibold text-white md:hidden"
            >
              <Video size={14} aria-hidden /> Join
            </button>
          )}

          <div className="mt-auto hidden items-center gap-2.5 px-2 pt-4 md:flex">
            <Avatar text={initials(profile.name)} size={34} />
            <div className="min-w-0">
              <p className="truncate text-[13px] font-semibold text-navy">{profile.name.trim() || "You"}</p>
              <p className="truncate text-[11.5px] text-muted">{roleLine || "Set your role"}</p>
            </div>
          </div>
        </aside>

        <div
          ref={scrollRef}
          id="cue-scroll"
          onScroll={(e) => scrollMemory.set(viewKey, e.currentTarget.scrollTop)}
          className="min-h-0 flex-1 overflow-y-auto"
        >
          <div key={viewKey} className="animate-fade-in">
            {reader.screen === "brief" && <BriefView />}
            {reader.screen === "deep" && <DeepDiveView />}
            {reader.screen === "saved" && <SavedView />}
            {reader.screen === "settings" && <SettingsView />}
          </div>
        </div>
      </div>
      {resetOpen && <ResetDialog onClose={() => setResetOpen(false)} />}
    </div>
  );
}
